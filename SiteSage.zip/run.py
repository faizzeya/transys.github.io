#!/usr/bin/env python3
"""SiteSage launcher.

Starts the local FastAPI server on a free loopback port, then opens a
native desktop window pointed at it. Falls back to the system browser if
a native webview is unavailable (common on bare Linux servers).

    python run.py              # desktop window
    python run.py --browser    # serve only, open in your browser
    python run.py --port 8931  # pin the port
"""

from __future__ import annotations

import argparse
import socket
import sys
import threading
import time
from pathlib import Path

# Make the package importable when run from a source checkout.
sys.path.insert(0, str(Path(__file__).parent))

from sitesage import __app_name__, __version__  # noqa: E402


def free_port(preferred: int = 0) -> int:
    if preferred:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            if probe.connect_ex(("127.0.0.1", preferred)) != 0:
                return preferred
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_until_up(port: int, timeout: float = 25.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.4)
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                return True
        time.sleep(0.15)
    return False


def serve(port: int) -> None:
    import uvicorn
    from sitesage.server import app

    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning",
                access_log=False)


def main() -> int:
    parser = argparse.ArgumentParser(prog="sitesage", description=f"{__app_name__} {__version__}")
    parser.add_argument("--browser", action="store_true",
                        help="serve only; open in the default browser")
    parser.add_argument("--port", type=int, default=0, help="port to bind (default: auto)")
    parser.add_argument("--no-window", action="store_true",
                        help="serve only; do not open anything")
    args = parser.parse_args()

    port = free_port(args.port)
    url = f"http://127.0.0.1:{port}"

    if args.no_window:
        print(f"{__app_name__} {__version__} serving at {url}")
        serve(port)
        return 0

    server = threading.Thread(target=serve, args=(port,), daemon=True)
    server.start()

    if not wait_until_up(port):
        print("Error: the local server did not start in time.", file=sys.stderr)
        return 1

    if args.browser:
        import webbrowser
        print(f"{__app_name__} running at {url}  (Ctrl+C to quit)")
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            return 0

    try:
        import webview  # pywebview
    except ImportError:
        import webbrowser
        print("pywebview is not installed; opening in your browser instead.")
        print(f"{__app_name__} running at {url}  (Ctrl+C to quit)")
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            return 0

    webview.create_window(
        f"{__app_name__}",
        url,
        width=1240,
        height=840,
        min_size=(940, 640),
        text_select=True,
    )
    try:
        webview.start()
    except Exception as exc:
        print(f"Could not open a native window ({exc}).", file=sys.stderr)
        print(f"Open {url} in your browser instead.", file=sys.stderr)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

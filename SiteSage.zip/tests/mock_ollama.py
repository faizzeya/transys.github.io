"""A stand-in Ollama server, so the full app path can be tested without a GPU.

Implements the three endpoints SiteSage uses: /api/tags, /api/embed and
/api/chat (streaming). Embeddings are deterministic hashed bag-of-words;
the "answer" echoes the context it was given so we can assert that
retrieval actually reached the model.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys

from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse

DIM = 256
app = FastAPI()


def vector(text: str) -> list[float]:
    values = [0.0] * DIM
    for word in text.lower().split():
        word = word.strip(".,;:()[]\"'")
        if len(word) < 3:
            continue
        index = int(hashlib.md5(word.encode()).hexdigest()[:8], 16) % DIM
        values[index] += 1.0
    norm = sum(v * v for v in values) ** 0.5
    return [v / norm for v in values] if norm else values


@app.get("/api/tags")
async def tags():
    return {"models": [
        {"name": "qwen2.5:7b-instruct"},
        {"name": "nomic-embed-text:latest"},
    ]}


@app.post("/api/embed")
async def embed(request: Request):
    body = await request.json()
    items = body.get("input") or []
    if isinstance(items, str):
        items = [items]
    return {"embeddings": [vector(t) for t in items]}


@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()
    messages = body.get("messages", [])
    last = messages[-1]["content"] if messages else ""

    # Pull the first numeric fact out of the supplied context and cite it,
    # imitating what a grounded model would do.
    context = last.split("CONTEXT:")[-1]
    numbers = re.findall(r"\b\d[\d,]{2,}\b", context)
    fact = numbers[0] if numbers else "no figure found"
    reply = (
        f"Based on the indexed sources, the relevant figure is {fact} [1]. "
        f"The context supplied contained {len(context)} characters [2]."
    )

    async def stream():
        for token in reply.split(" "):
            yield json.dumps({"message": {"content": token + " "}, "done": False}) + "\n"
        yield json.dumps({"message": {"content": ""}, "done": True}) + "\n"

    return StreamingResponse(stream(), media_type="application/x-ndjson")


if __name__ == "__main__":
    import uvicorn
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 11500
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="error")

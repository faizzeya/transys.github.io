"""Full application flow test: HTTP API from ingest through streaming answer."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).parent.parent
SITE_DIR = Path(__file__).parent / "fixture_site"

SITE_PORT, OLLAMA_PORT, APP_PORT = 8801, 11500, 8812
SITE = f"http://127.0.0.1:{SITE_PORT}"
APP = f"http://127.0.0.1:{APP_PORT}"

failures: list[str] = []
checks = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global checks
    checks += 1
    if condition:
        print(f"  PASS  {label}")
    else:
        print(f"  FAIL  {label}" + (f"  -- {detail}" if detail else ""))
        failures.append(label)


def wait_for(url: str, timeout: float = 25.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            httpx.get(url, timeout=2.0)
            return True
        except Exception:
            time.sleep(0.3)
    return False


def run() -> int:
    procs = [
        subprocess.Popen([sys.executable, "-m", "http.server", str(SITE_PORT),
                          "--bind", "127.0.0.1"], cwd=str(SITE_DIR),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
        subprocess.Popen([sys.executable, str(Path(__file__).parent / "mock_ollama.py"),
                          str(OLLAMA_PORT)],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
        subprocess.Popen([sys.executable, str(ROOT / "run.py"), "--no-window",
                          "--port", str(APP_PORT)], cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
    ]

    try:
        assert wait_for(f"{SITE}/index.html"), "fixture site did not start"
        assert wait_for(f"http://127.0.0.1:{OLLAMA_PORT}/api/tags"), "mock ollama did not start"
        assert wait_for(f"{APP}/api/health"), "app did not start"

        client = httpx.Client(timeout=120.0)

        print("\nPoint the app at the mock Ollama")
        client.post(f"{APP}/api/settings", json={"values": {
            "ollama_host": f"http://127.0.0.1:{OLLAMA_PORT}",
            "max_pages": 20, "max_depth": 3, "crawl_delay": 0.0,
        }})
        health = client.get(f"{APP}/api/health").json()
        check("ollama detected as running", health["ollama"]["running"] is True)
        check("chat model reported ready", health["ollama"]["chat_model_ready"] is True)
        check("embed model reported ready", health["ollama"]["embed_model_ready"] is True)

        print("\nIngest")
        job = client.post(f"{APP}/api/ingest",
                          json={"url": f"{SITE}/index.html", "name": "Northfield"}).json()
        job_id = job["id"]
        check("job created", bool(job_id))

        final = None
        deadline = time.time() + 120
        while time.time() < deadline:
            final = client.get(f"{APP}/api/ingest/{job_id}").json()
            if final["status"] in ("done", "error", "cancelled"):
                break
            time.sleep(0.5)

        print(f"  status={final['status']}  {final['message']}")
        if final["status"] == "error":
            print(f"  error: {final['error']}")

        check("ingest completed", final["status"] == "done", final.get("error", ""))
        check("pages were crawled", final["pages_visited"] >= 6, str(final["pages_visited"]))
        check("documents found", final["docs_found"] >= 6, str(final["docs_found"]))
        check("chunks embedded", final["chunks_embedded"] >= 8, str(final["chunks_embedded"]))
        check("progress reached 100%", final["progress"] == 1.0, str(final["progress"]))
        check("log recorded activity", len(final["log"]) >= 5, str(len(final["log"])))

        workspace_id = final["workspace_id"]
        check("workspace created", bool(workspace_id))

        print("\nWorkspace")
        workspaces = client.get(f"{APP}/api/workspaces").json()
        check("workspace listed", len(workspaces) == 1, str(len(workspaces)))

        workspace = client.get(f"{APP}/api/workspaces/{workspace_id}").json()
        docs = workspace["documents"]
        kinds = {}
        for d in docs:
            kinds[d["kind"]] = kinds.get(d["kind"], 0) + 1
        print(f"  documents: {kinds}")
        check("PDFs in workspace", kinds.get("pdf", 0) == 2, str(kinds))
        check("DOCX in workspace", kinds.get("docx", 0) == 1, str(kinds))
        check("HTML in workspace", kinds.get("html", 0) >= 4, str(kinds))
        check("stats recorded", workspace["stats"].get("chunks", 0) > 0,
              str(workspace["stats"]))

        print("\nAsk (streaming)")
        events = []
        with client.stream("POST", f"{APP}/api/ask", json={
            "workspace_id": workspace_id,
            "question": "What is the late application deadline and fee?",
        }) as resp:
            check("ask returns 200", resp.status_code == 200, str(resp.status_code))
            for line in resp.iter_lines():
                if line.strip():
                    events.append(json.loads(line))

        types = [e["type"] for e in events]
        check("no error event", "error" not in types,
              str([e.get("error") for e in events if e["type"] == "error"]))
        check("sources event sent first", types and types[0] == "sources", str(types[:3]))
        check("tokens streamed", types.count("token") > 3, str(types.count("token")))
        check("done event sent", types[-1] == "done" if types else False, str(types[-1:]))

        sources = events[0]["sources"] if events else []
        print(f"  retrieved {len(sources)} sources:")
        for s in sources[:5]:
            loc = f" ({s['label']})" if s["label"] else ""
            print(f"    [{s['n']}] {s['kind']:5} {s['title'][:44]:<46}{loc}")

        check("sources returned", len(sources) >= 3, str(len(sources)))
        check("sources numbered from 1", sources and sources[0]["n"] == 1)
        check("sources carry a URL", all(s["url"].startswith("http") for s in sources))
        check("sources carry a snippet", all(len(s["snippet"]) > 20 for s in sources))
        check("PDF source cites a page",
              any(s["kind"] == "pdf" and s["page"] for s in sources),
              str([(s["kind"], s["page"]) for s in sources]))
        check("scores descend",
              all(sources[i]["score"] >= sources[i + 1]["score"]
                  for i in range(len(sources) - 1)),
              str([s["score"] for s in sources]))

        answer = events[-1].get("answer", "")
        print(f"  answer: {answer[:110]}...")
        check("answer non-empty", len(answer) > 20, answer[:60])

        print("\nHistory")
        workspace = client.get(f"{APP}/api/workspaces/{workspace_id}").json()
        history = workspace["history"]
        check("both turns saved", len(history) == 2, str(len(history)))
        check("assistant turn keeps sources",
              len(history[-1]["sources"]) >= 3 if len(history) == 2 else False)

        client.post(f"{APP}/api/workspaces/{workspace_id}/clear-history")
        workspace = client.get(f"{APP}/api/workspaces/{workspace_id}").json()
        check("history cleared", workspace["history"] == [])

        print("\nError handling")
        bad = client.post(f"{APP}/api/ask", json={"workspace_id": 9999, "question": "hi"})
        check("unknown workspace rejected", bad.status_code == 404, str(bad.status_code))

        empty = client.post(f"{APP}/api/ingest", json={"url": "", "name": ""})
        check("empty URL rejected", empty.status_code == 400, str(empty.status_code))

        missing = client.get(f"{APP}/api/ingest/nosuchjob")
        check("unknown job rejected", missing.status_code == 404, str(missing.status_code))

        print("\nCleanup")
        client.delete(f"{APP}/api/workspaces/{workspace_id}")
        check("workspace deleted", client.get(f"{APP}/api/workspaces").json() == [])

        client.close()
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()

    print("\n" + "=" * 62)
    if failures:
        print(f"{len(failures)} of {checks} checks FAILED:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"All {checks} checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

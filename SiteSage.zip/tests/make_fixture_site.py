"""Build a small local website (HTML + PDF + DOCX) to test the pipeline against."""

from pathlib import Path

SITE = Path(__file__).parent / "fixture_site"
SITE.mkdir(exist_ok=True)


def page(title: str, body: str, links: list[str]) -> str:
    nav = " ".join(f'<a href="{href}">{label}</a>' for label, href in links)
    return f"""<!DOCTYPE html>
<html><head><title>{title}</title></head>
<body>
<nav class="site-nav">{nav} <a href="/login">Login</a></nav>
<header class="banner">Northfield Institute of Technology</header>
<main>
{body}
</main>
<footer class="site-footer">Copyright 2026 Northfield. Cookie policy. Privacy.</footer>
<script>console.log("this should never be indexed");</script>
</body></html>"""


LINKS = [
    ("Home", "/index.html"),
    ("Admissions", "/admissions.html"),
    ("Fees", "/fees.html"),
    ("Research", "/research/index.html"),
]

(SITE / "index.html").write_text(page(
    "Northfield Institute of Technology",
    """
    <h1>Northfield Institute of Technology</h1>
    <p>Northfield Institute of Technology is a research university founded in 1974,
    located in Northfield. The institute enrols approximately 8,400 students across
    four faculties: Engineering, Computer Science, Applied Sciences, and Business.</p>
    <h2>Our faculties</h2>
    <p>The Faculty of Computer Science is the largest, with 3,100 enrolled students
    and 82 full-time academic staff. It offers undergraduate and postgraduate
    degrees in software engineering, artificial intelligence, and data science.</p>
    <h2>Accreditation</h2>
    <p>All engineering programmes are accredited by the National Engineering
    Accreditation Council under certificate NEAC-2024-1187, valid until 31 December 2029.</p>
    """, LINKS))

(SITE / "admissions.html").write_text(page(
    "Admissions - Northfield",
    """
    <h1>Admissions</h1>
    <h2>Application deadlines</h2>
    <p>Applications for the Autumn 2026 intake open on 3 February 2026 and close on
    18 April 2026. Late applications are accepted until 2 May 2026 with a surcharge.</p>
    <h2>Entry requirements</h2>
    <p>Undergraduate applicants must hold a higher secondary certificate with a minimum
    aggregate of 65 percent. Applicants to the Faculty of Computer Science must have
    studied mathematics at the higher secondary level.</p>
    <p>Postgraduate applicants require a four-year bachelor's degree with a minimum
    CGPA of 2.75 on a 4.00 scale, plus a passing score on the NITAT entrance test.</p>
    <h2>Documents</h2>
    <p>Full details are in the <a href="/docs/admissions-policy.pdf">admissions policy (PDF)</a>
    and the <a href="/docs/scholarship-form.docx">scholarship application form</a>.</p>
    """, LINKS))

(SITE / "fees.html").write_text(page(
    "Fees - Northfield",
    """
    <h1>Tuition and fees</h1>
    <p>The 2026 tuition fee for undergraduate programmes is 412,000 per academic year,
    payable in two instalments. The postgraduate tuition fee is 486,000 per academic year.</p>
    <h2>Additional charges</h2>
    <p>A one-time admission processing charge of 25,000 applies to all new students.
    The library and laboratory access charge is 18,500 per year.</p>
    <h2>Refunds</h2>
    <p>Students withdrawing within the first two weeks of a semester receive a 90 percent
    refund. After week four, no refund is issued.</p>
    """, LINKS))

(SITE / "research").mkdir(exist_ok=True)
(SITE / "research" / "index.html").write_text(page(
    "Research - Northfield",
    """
    <h1>Research at Northfield</h1>
    <p>Northfield operates eleven research centres. The Centre for Applied Machine
    Intelligence received a competitive grant of 94 million in 2025 to study
    formal verification of autonomous systems.</p>
    <p>See the <a href="/docs/research-report-2025.pdf">2025 research report (PDF)</a>.</p>
    """, LINKS))

# Deliberate traps: a login page and an image that must be skipped.
(SITE / "login.html").write_text(page("Login", "<h1>Login</h1><p>Members only.</p>", LINKS))

(SITE / "robots.txt").write_text("User-agent: *\nDisallow: /private/\nAllow: /\n")

# ---- PDFs -----------------------------------------------------------------

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table

DOCS = SITE / "docs"
DOCS.mkdir(exist_ok=True)
styles = getSampleStyleSheet()


def build_pdf(path, title, pages):
    doc = SimpleDocTemplate(str(path), pagesize=A4, title=title)
    flow = []
    for i, blocks in enumerate(pages):
        for block in blocks:
            if isinstance(block, list):
                flow.append(Table(block))
            else:
                flow.append(Paragraph(block, styles["BodyText"]))
            flow.append(Spacer(1, 10))
        if i < len(pages) - 1:
            flow.append(PageBreak())
    doc.build(flow)


build_pdf(DOCS / "admissions-policy.pdf", "Northfield Admissions Policy 2026", [
    [
        "<b>NORTHFIELD INSTITUTE OF TECHNOLOGY</b>",
        "<b>Admissions Policy 2026</b>",
        "Section 1. Scope. This policy governs admission to all undergraduate and "
        "postgraduate programmes offered by the Institute for the 2026 academic year.",
        "Section 2. Application window. The application portal opens on 3 February 2026 "
        "and closes at 23:59 on 18 April 2026. Applications received after this time are "
        "processed under the late application provisions of Section 7.",
    ],
    [
        "Section 3. Eligibility. Undergraduate applicants must present a higher secondary "
        "certificate with an aggregate of not less than 65 percent. Applicants to computing "
        "programmes must additionally present a pass in higher secondary mathematics.",
        "Section 4. Entrance examination. All applicants must sit the Northfield Institute "
        "of Technology Admission Test (NITAT). The qualifying score is 55 for undergraduate "
        "programmes and 62 for postgraduate programmes.",
        "Section 5. Quota reservations. Five percent of seats in each programme are reserved "
        "for applicants from underserved districts, and two percent for children of Institute staff.",
    ],
    [
        "Section 6. Fee schedule for applications.",
        [["Category", "Application fee", "Late fee"],
         ["Undergraduate", "4,500", "2,000"],
         ["Postgraduate", "6,000", "2,500"],
         ["International", "12,000", "4,000"]],
        "Section 7. Late applications. Applications submitted between 19 April 2026 and "
        "2 May 2026 are accepted on payment of the late fee shown above. No application "
        "is accepted after 2 May 2026 under any circumstances.",
        "Section 8. Appeals. An applicant may appeal a rejection within fourteen days by "
        "written notice to the Registrar. The Admissions Appeal Committee decides within thirty days.",
    ],
])

build_pdf(DOCS / "research-report-2025.pdf", "Northfield Research Report 2025", [
    [
        "<b>Research Report 2025</b>",
        "The Institute published 486 peer-reviewed papers in 2025, an increase of 12 percent "
        "over 2024. Total external research funding reached 1.34 billion.",
        "The Centre for Applied Machine Intelligence was awarded a grant of 94 million for "
        "work on formal verification of autonomous systems, the largest single award in "
        "the Institute's history.",
    ],
    [
        "Doctoral output. Fifty-eight doctoral degrees were conferred in 2025 across all "
        "faculties, of which twenty-two were in the Faculty of Computer Science.",
        "Industry partnerships. The Institute maintained forty-one active industry research "
        "agreements in 2025, with a combined contract value of 610 million.",
    ],
])

# ---- DOCX -----------------------------------------------------------------

import docx

d = docx.Document()
d.core_properties.title = "Northfield Scholarship Application Form"
d.add_heading("Scholarship Application Form 2026", level=1)
d.add_paragraph(
    "This form is used to apply for merit and need-based scholarships at Northfield "
    "Institute of Technology for the 2026 academic year."
)
d.add_heading("Eligibility", level=2)
d.add_paragraph(
    "Merit scholarships are available to students with a CGPA of 3.50 or above. "
    "Need-based scholarships require a household income below 1,200,000 per year, "
    "evidenced by a tax certificate."
)
d.add_heading("Award values", level=2)
table = d.add_table(rows=4, cols=3)
rows = [
    ("Scholarship", "Coverage", "Number available"),
    ("Chancellor's Merit Award", "100 percent tuition", "12"),
    ("Faculty Merit Award", "50 percent tuition", "45"),
    ("Need-Based Grant", "30 percent tuition", "120"),
]
for r, row in enumerate(rows):
    for c, value in enumerate(row):
        table.rows[r].cells[c].text = value
d.add_heading("Submission deadline", level=2)
d.add_paragraph(
    "Completed forms must reach the Financial Aid Office by 30 May 2026. "
    "Forms received after this date are not considered."
)
d.save(str(DOCS / "scholarship-form.docx"))

print(f"Fixture site built at {SITE}")
for f in sorted(SITE.rglob("*")):
    if f.is_file():
        print(f"  {f.relative_to(SITE)}  ({f.stat().st_size:,} bytes)")

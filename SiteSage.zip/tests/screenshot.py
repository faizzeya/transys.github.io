"""Render the UI in Chromium so the interface can be reviewed visually."""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

import httpx
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent.parent
SITE_DIR = Path(__file__).parent / "fixture_site"
OUT = ROOT / "screenshots"
OUT.mkdir(exist_ok=True)

SITE_PORT, OLLAMA_PORT, APP_PORT = 8802, 11501, 8813
SITE = f"http://127.0.0.1:{SITE_PORT}"
APP = f"http://127.0.0.1:{APP_PORT}"


def wait_for(url, timeout=30.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            httpx.get(url, timeout=2.0)
            return True
        except Exception:
            time.sleep(0.3)
    return False


procs = [
    subprocess.Popen([sys.executable, "-m", "http.server", str(SITE_PORT), "--bind", "127.0.0.1"],
                     cwd=str(SITE_DIR), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
    subprocess.Popen([sys.executable, str(Path(__file__).parent / "mock_ollama.py"), str(OLLAMA_PORT)],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
    subprocess.Popen([sys.executable, str(ROOT / "run.py"), "--no-window", "--port", str(APP_PORT)],
                     cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL),
]

try:
    wait_for(f"{SITE}/index.html")
    wait_for(f"http://127.0.0.1:{OLLAMA_PORT}/api/tags")
    wait_for(f"{APP}/api/health")

    client = httpx.Client(timeout=120.0)
    client.post(f"{APP}/api/settings", json={"values": {
        "ollama_host": f"http://127.0.0.1:{OLLAMA_PORT}",
        "max_pages": 20, "crawl_delay": 0.0,
    }})

    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page(viewport={"width": 1240, "height": 840},
                                device_scale_factor=2)

        # --- 1. Start screen -------------------------------------------
        page.goto(APP)
        page.wait_for_timeout(1200)
        page.fill("#url-input", f"{SITE}/index.html")
        page.screenshot(path=str(OUT / "1-start.png"))
        print("captured 1-start.png")

        # --- 2. Ingest in progress -------------------------------------
        page.click("#ingest-form button[type=submit]")
        page.wait_for_timeout(2500)
        page.screenshot(path=str(OUT / "2-indexing.png"))
        print("captured 2-indexing.png")

        # Wait for completion.
        for _ in range(120):
            if page.is_visible("#open-chat-btn"):
                break
            page.wait_for_timeout(500)
        page.wait_for_timeout(600)
        page.screenshot(path=str(OUT / "3-indexed.png"))
        print("captured 3-indexed.png")

        # --- 3. Chat ----------------------------------------------------
        page.click("#open-chat-btn")
        page.wait_for_timeout(1200)
        page.screenshot(path=str(OUT / "4-chat-empty.png"))
        print("captured 4-chat-empty.png")

        page.fill("#question-input", "What is the late application deadline and fee?")
        page.click("#ask-btn")
        page.wait_for_timeout(4500)
        page.screenshot(path=str(OUT / "5-answer.png"))
        print("captured 5-answer.png")

        # --- 4. Sources drawer ------------------------------------------
        page.click("#docs-btn")
        page.wait_for_timeout(900)
        page.screenshot(path=str(OUT / "6-sources.png"))
        print("captured 6-sources.png")
        page.click("#drawer-close")
        page.wait_for_timeout(400)

        # --- 5. Settings -------------------------------------------------
        page.click("#settings-btn")
        page.wait_for_timeout(900)
        page.screenshot(path=str(OUT / "7-settings.png"))
        print("captured 7-settings.png")

        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.wait_for_timeout(500)
        if errors:
            print("JS ERRORS:", errors)
        else:
            print("no JS errors")

        browser.close()
finally:
    for p in procs:
        p.terminate()
    for p in procs:
        try:
            p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            p.kill()

print("done")

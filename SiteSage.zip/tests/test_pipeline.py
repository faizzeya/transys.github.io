"""End-to-end pipeline check against the local fixture site.

Runs crawl -> extract -> chunk -> embed -> store -> retrieve with a
deterministic stub embedder, so the whole path is exercised without
needing Ollama installed in this environment.
"""

from __future__ import annotations

import asyncio
import hashlib
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from sitesage.chunker import chunk_document, embedding_text
from sitesage.config import Settings
from sitesage.crawler import crawl, normalise, should_skip, same_site
from sitesage.rag import keywords
from sitesage.store import Store

SITE_DIR = Path(__file__).parent / "fixture_site"
PORT = 8799
BASE = f"http://127.0.0.1:{PORT}"

failures: list[str] = []
checks = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global checks
    checks += 1
    if condition:
        print(f"  PASS  {label}")
    else:
        print(f"  FAIL  {label}" + (f"  -- {detail}" if detail else ""))
        failures.append(label)


# ---------------------------------------------------------------------------
# A deterministic stand-in for a real embedding model.
# Hashed bag-of-words gives real lexical overlap signal, which is enough to
# prove retrieval wiring works end to end.
# ---------------------------------------------------------------------------

DIM = 256


def stub_vector(text: str) -> np.ndarray:
    vector = np.zeros(DIM, dtype=np.float32)
    for word in text.lower().split():
        word = word.strip(".,;:()[]\"'")
        if len(word) < 3:
            continue
        index = int(hashlib.md5(word.encode()).hexdigest()[:8], 16) % DIM
        vector[index] += 1.0
    norm = np.linalg.norm(vector)
    return vector / norm if norm else vector


class StubClient:
    async def embed(self, texts, batch_size=16, timeout=180.0):
        return np.vstack([stub_vector(t) for t in texts]) if texts else np.zeros((0, DIM), np.float32)

    async def embed_one(self, text):
        return stub_vector(text)


# ---------------------------------------------------------------------------


def test_unit_helpers() -> None:
    print("\nURL handling")
    check("normalise strips fragments and trailing slash",
          normalise("https://Example.com/Page/#top") == "https://example.com/Page")
    check("normalise drops default port",
          normalise("https://example.com:443/a") == "https://example.com/a")
    check("images are skipped", should_skip("https://x.com/logo.png") != "")
    check("xlsx reported as unsupported", "unsupported" in should_skip("https://x.com/a.xlsx"))
    check("login pages skipped", should_skip("https://x.com/login") != "")
    check("pdf is not skipped", should_skip("https://x.com/a.pdf") == "")
    check("same-site exact host",
          same_site("https://a.com/x", "https://a.com/", False))
    check("subdomain excluded by default",
          not same_site("https://sub.a.com/x", "https://a.com/", False))
    check("subdomain included when enabled",
          same_site("https://sub.a.com/x", "https://a.com/", True))

    print("\nKeyword extraction")
    terms = [t.lower() for t in keywords("What is the deadline for SEN-323 applications?")]
    check("course code preserved", any("sen" in t for t in terms), str(terms))
    check("stopwords removed", "the" not in terms and "what" not in terms, str(terms))
    check("content word kept", "deadline" in terms, str(terms))


async def test_pipeline() -> None:
    settings = Settings(
        max_pages=25, max_depth=3, crawl_delay=0.0, concurrency=4,
        respect_robots=True, chunk_words=200, chunk_overlap_words=40,
        top_k=6, candidate_pool=30,
    )

    print("\nCrawl")
    started = time.time()
    result = await crawl(BASE + "/index.html", settings)
    elapsed = time.time() - started

    kinds = {}
    for doc in result.docs:
        kinds[doc.kind] = kinds.get(doc.kind, 0) + 1

    print(f"  crawled {result.visited} URLs in {elapsed:.1f}s -> {len(result.docs)} docs {kinds}")
    for doc in sorted(result.docs, key=lambda d: d.kind):
        print(f"    [{doc.kind:5}] {doc.title[:52]:<54} {doc.word_count:>5} words")

    check("html pages indexed", kinds.get("html", 0) >= 4, str(kinds))
    check("both PDFs indexed", kinds.get("pdf", 0) == 2, str(kinds))
    check("DOCX indexed", kinds.get("docx", 0) == 1, str(kinds))

    all_text = "\n".join(d.text for d in result.docs)
    check("boilerplate nav stripped", "Cookie policy" not in all_text)
    check("inline script stripped", "should never be indexed" not in all_text)
    check("PDF body text extracted", "qualifying score is 55" in all_text)
    check("PDF table extracted", "12,000" in all_text and "4,000" in all_text)
    check("multi-page PDF read past page 1", "fourteen days" in all_text)
    check("DOCX table extracted", "Chancellor's Merit Award" in all_text)
    check("DOCX body extracted", "30 May 2026" in all_text)

    pdf_doc = next(d for d in result.docs if "admissions-policy" in d.url)
    pages = {s.page for s in pdf_doc.sections if s.page}
    check("PDF page numbers recorded for citation", pages == {1, 2, 3}, str(pages))

    html_doc = next(d for d in result.docs if d.url.endswith("admissions.html"))
    labels = [s.label for s in html_doc.sections if s.label]
    check("HTML sections labelled by heading",
          any("Entry requirements" in l for l in labels), str(labels))

    print("\nChunking")
    total = 0
    for doc in result.docs:
        chunks = chunk_document(doc, settings.chunk_words, settings.chunk_overlap_words)
        total += len(chunks)
        oversize = [c for c in chunks if len(c["text"].split()) > settings.chunk_words * 1.6]
        check(f"chunks sized sanely for {doc.kind}:{doc.title[:24]}", not oversize,
              f"{len(oversize)} oversize")
    check("chunks produced", total >= 8, f"{total} chunks")
    print(f"  {total} chunks total")

    print("\nStore and retrieval")
    with tempfile.TemporaryDirectory() as tmp:
        store = Store(Path(tmp) / "t.db")
        client = StubClient()
        workspace_id = store.create_workspace("Northfield", BASE, "stub")

        for doc in result.docs:
            chunks = chunk_document(doc, settings.chunk_words, settings.chunk_overlap_words)
            if not chunks:
                continue
            document_id = store.add_document(workspace_id, doc.url, doc.title,
                                             doc.kind, doc.word_count)
            vectors = await client.embed([embedding_text(c, doc.title) for c in chunks])
            store.add_chunks(workspace_id, document_id, chunks, vectors)

        stored = store.chunk_count(workspace_id)
        check("chunks persisted", stored == total, f"{stored} vs {total}")

        # Round-trip the vectors through SQLite and confirm they survive.
        matrix, ids = store._matrix(workspace_id)
        check("embedding matrix rebuilt", matrix.shape == (total, DIM), str(matrix.shape))
        check("vectors normalised on load",
              bool(np.allclose(np.linalg.norm(matrix, axis=1), 1.0, atol=1e-5)))

        queries = [
            ("What is the late application deadline?", "2 May 2026"),
            ("How much is undergraduate tuition?", "412,000"),
            ("What CGPA do I need for a merit scholarship?", "3.50"),
            ("What is the NITAT qualifying score for postgraduates?", "62"),
            ("How big was the machine intelligence grant?", "94 million"),
        ]

        for question, expected in queries:
            vector = await client.embed_one(question)
            semantic = store.search(workspace_id, vector, settings.candidate_pool)
            lexical = store.keyword_search(workspace_id, keywords(question),
                                           settings.candidate_pool)

            merged: dict[int, float] = {}
            for cid, s in semantic:
                merged[cid] = merged.get(cid, 0) + 0.65 * s
            for cid, s in lexical:
                merged[cid] = merged.get(cid, 0) + 0.35 * s

            top = sorted(merged.items(), key=lambda kv: -kv[1])[:settings.top_k]
            hydrated = store.hydrate([cid for cid, _ in top])
            body = " ".join(c.text for c in hydrated.values())

            check(f'retrieval finds "{expected}"', expected in body,
                  f"q={question!r}")

        # Citation metadata must survive the round trip.
        vector = await client.embed_one("late application fee for international applicants")
        hits = store.search(workspace_id, vector, 5)
        rows = store.hydrate([cid for cid, _ in hits])
        pdf_hits = [c for c in rows.values() if c.kind == "pdf"]
        check("pdf chunks carry a page label",
              any(c.page is not None and c.label.startswith("page") for c in pdf_hits),
              str([(c.kind, c.label) for c in rows.values()]))

        print("\nChat history")
        store.add_message(workspace_id, "user", "test question")
        store.add_message(workspace_id, "assistant", "test answer",
                          [{"n": 1, "title": "T", "url": "u"}])
        history = store.history(workspace_id)
        check("history round-trips", len(history) == 2 and history[0]["role"] == "user")
        check("sources deserialise", history[1]["sources"][0]["title"] == "T")

        store.clear_history(workspace_id)
        check("history clears", store.history(workspace_id) == [])

        store.delete_workspace(workspace_id)
        check("workspace deletes", store.list_workspaces() == [])
        store.close()

    print("\nRobots.txt")
    strict = Settings(max_pages=25, max_depth=3, crawl_delay=0.0, respect_robots=True)
    blocked = await crawl(BASE + "/private/secret.html", strict)
    check("disallowed path refused",
          any("robots" in why for _, why in blocked.skipped) or not blocked.docs,
          str(blocked.skipped[:3]))


def main() -> int:
    server = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1"],
        cwd=str(SITE_DIR),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    time.sleep(1.5)
    try:
        test_unit_helpers()
        asyncio.run(test_pipeline())
    finally:
        server.terminate()
        server.wait(timeout=5)

    print("\n" + "=" * 62)
    if failures:
        print(f"{len(failures)} of {checks} checks FAILED:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"All {checks} checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Licensing audit

Written because SiteSage is intended for commercial sale. Everything below is
permissively licensed and can be bundled into a closed-source product you sell.
No copyleft obligations, no source-disclosure requirements.

This is an engineering summary, not legal advice. If you sell at volume, have a
lawyer confirm it.

---

## Python dependencies

| Package | Licence | Bundling a commercial closed-source app |
|---|---|---|
| fastapi | MIT | Yes |
| uvicorn | BSD-3-Clause | Yes |
| httpx | BSD-3-Clause | Yes |
| beautifulsoup4 | MIT | Yes |
| lxml | BSD-3-Clause | Yes |
| pdfplumber | MIT | Yes |
| pdfminer.six (via pdfplumber) | MIT | Yes |
| python-docx | MIT | Yes |
| numpy | BSD-3-Clause | Yes |
| pywebview | BSD-3-Clause | Yes |
| pydantic | MIT | Yes |
| Python itself | PSF | Yes |
| SQLite | Public domain | Yes |

All of these require only that you preserve their copyright notices. Ship a
`THIRD-PARTY-LICENSES.txt` in your installer and you have met the obligation.

---

## Deliberately avoided

**PyMuPDF / fitz** — the fastest PDF library in Python, and **AGPL-3.0**. Using
it in a product you distribute without publishing your own source would breach
the licence; a commercial licence from Artifex costs meaningful money. This is
the most common licensing trap in PDF tooling, and it is why this project uses
`pdfplumber` instead. Do not swap it back in.

**Unstructured.io** — Apache-2.0 core, but several high-value parsers sit behind
a commercial tier. Easy to end up depending on a paid component by accident.

---

## PyInstaller

PyInstaller is GPL-2.0 **with a linking exception** that explicitly permits
distributing bundled applications under any licence, including proprietary. The
exception covers exactly this use. You do not need to open-source SiteSage
because you packaged it with PyInstaller.

You must not modify PyInstaller's bootloader and keep the result closed; using
it unmodified — which is what `sitesage.spec` does — is fine.

---

## Ollama and the models

**Ollama** itself is MIT. It is a separate install, not bundled, so its licence
does not attach to your product regardless.

The models are separate works with their own licences, and this matters because
the model, not your code, is what generates the answers your customers pay for:

| Model | Licence | Commercial use |
|---|---|---|
| `qwen2.5` (all sizes) | Apache-2.0 | Yes, unrestricted |
| `nomic-embed-text` | Apache-2.0 | Yes, unrestricted |
| `mistral:7b` (v0.1–0.3) | Apache-2.0 | Yes, unrestricted |
| `llama3.1` | Meta Llama 3.1 Community License | Yes, but conditional |
| `gemma2` | Gemma Terms of Use | Yes, with use restrictions |

The defaults shipped here — **qwen2.5 + nomic-embed-text** — are both Apache-2.0
and were chosen for that reason. They carry no attribution requirement in your
UI and no user-count threshold.

Watch out for **Llama 3.1**: it is free for commercial use only below 700 million
monthly active users, and it requires displaying "Built with Llama" plus naming
derivative models "Llama-…". Not a problem at your scale, but it is a condition,
and it is worth not making it your default for that reason alone.

Since the user pulls models themselves through Ollama, you are not redistributing
model weights, which keeps your obligations lighter either way. Still, if you
recommend a default in your documentation, recommend an Apache-2.0 one.

---

## Content and crawling

Your product downloads and processes third-party web content on the user's
behalf. Two things worth putting in your terms of sale:

1. **robots.txt is honoured by default.** Keep it that way, and make the toggle
   clearly the user's decision. It is a meaningful liability difference between
   "our tool respects crawl directives" and "our tool ignores them."

2. **The user is responsible for what they index.** Standard language: the
   customer warrants they have the right to access and process the content they
   point the tool at. This matters most for paywalled and licensed material.

Because nothing is uploaded anywhere, you are not storing or transmitting your
customers' documents — which removes most of the data-protection surface a
cloud version of this product would have. That is worth stating plainly in your
marketing; for buyers in law, healthcare, and government it is the deciding
factor.

# PyInstaller spec for SiteSage.
#
# Build:
#   pip install pyinstaller
#   pyinstaller sitesage.spec --clean --noconfirm
#
# Output lands in dist/. Build on each OS you intend to sell for -
# PyInstaller does not cross-compile.

import sys
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

block_cipher = None

hidden = (
    collect_submodules("uvicorn")
    + collect_submodules("fastapi")
    + collect_submodules("pdfminer")
    + [
        "uvicorn.logging",
        "uvicorn.loops.auto",
        "uvicorn.protocols.http.auto",
        "uvicorn.protocols.websockets.auto",
        "uvicorn.lifespan.on",
        "anyio._backends._asyncio",
        "pdfplumber",
        "docx",
        "lxml._elementpath",
    ]
)

datas = [("sitesage/static", "sitesage/static")]
datas += collect_data_files("pdfplumber")
datas += collect_data_files("pdfminer")
datas += collect_data_files("docx")

a = Analysis(
    ["run.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    runtime_hooks=[],
    # Trim the heavy scientific/GUI stack PyInstaller otherwise drags in.
    excludes=["matplotlib", "scipy", "pandas", "PIL", "tkinter",
              "PyQt5", "PySide2", "notebook", "IPython", "pytest"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="SiteSage",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,          # no terminal window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="assets/icon.icns" if sys.platform == "darwin" else "assets/icon.ico",
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="SiteSage",
)

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="SiteSage.app",
        icon="assets/icon.icns",
        bundle_identifier="com.transys.sitesage",
        info_plist={
            "CFBundleShortVersionString": "1.0.0",
            "NSHighResolutionCapable": True,
            "LSMinimumSystemVersion": "11.0",
        },
    )

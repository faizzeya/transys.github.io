"""Text extraction from HTML pages, PDFs, Word documents and plain text.

Every extractor returns an ExtractedDoc holding one or more Sections. A
section carries an optional page/anchor label so the answer can cite
"page 14" for a PDF or a heading anchor for a web page.
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from typing import Iterable

from bs4 import BeautifulSoup

# Tags whose contents are navigation/boilerplate rather than document text.
_BOILERPLATE_TAGS = (
    "script", "style", "noscript", "nav", "header", "footer", "aside",
    "form", "iframe", "svg", "canvas", "button", "template",
)

# Class/id fragments that almost always mark chrome rather than content.
_BOILERPLATE_HINTS = re.compile(
    r"(nav|menu|sidebar|footer|header|banner|cookie|consent|breadcrumb|"
    r"share|social|advert|promo|subscribe|newsletter|related|comment|"
    r"pagination|skip-link|offcanvas|modal|popup)",
    re.I,
)

_WS = re.compile(r"[ \t ]+")
_BLANKS = re.compile(r"\n{3,}")


@dataclass
class Section:
    """A contiguous run of text with a citable location label."""

    text: str
    label: str = ""          # e.g. "page 12" or "Admissions Policy"
    page: int | None = None  # 1-based page number for paginated formats


@dataclass
class ExtractedDoc:
    url: str
    title: str
    kind: str                # html | pdf | docx | text
    sections: list[Section] = field(default_factory=list)
    error: str = ""

    @property
    def text(self) -> str:
        return "\n\n".join(s.text for s in self.sections if s.text)

    @property
    def word_count(self) -> int:
        return len(self.text.split())


def _clean(text: str) -> str:
    """Normalise whitespace without destroying paragraph structure."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _WS.sub(" ", text)
    lines = [ln.strip() for ln in text.split("\n")]
    text = "\n".join(lines)
    return _BLANKS.sub("\n\n", text).strip()


# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------

def _pick_main(soup: BeautifulSoup):
    """Return the element most likely to hold the page's real content."""
    for selector in ("main", "article", '[role="main"]', "#content",
                     "#main", ".content", ".post", ".entry-content"):
        node = soup.select_one(selector)
        if node and len(node.get_text(strip=True)) > 200:
            return node
    return soup.body or soup


def extract_html(html: str, url: str) -> ExtractedDoc:
    """Strip chrome from an HTML page and split it on headings.

    Splitting on headings means a citation can name the section it came
    from, which reads far better than a bare URL.
    """
    soup = BeautifulSoup(html, "lxml")

    title = ""
    if soup.title and soup.title.string:
        title = soup.title.string.strip()
    if not title:
        h1 = soup.find("h1")
        title = h1.get_text(strip=True) if h1 else url

    for tag in soup(_BOILERPLATE_TAGS):
        tag.decompose()

    for node in soup.find_all(attrs={"class": _BOILERPLATE_HINTS}):
        node.decompose()
    for node in soup.find_all(attrs={"id": _BOILERPLATE_HINTS}):
        node.decompose()

    main = _pick_main(soup)

    sections: list[Section] = []
    current_label = ""
    buffer: list[str] = []

    def flush() -> None:
        body = _clean("\n\n".join(buffer))
        if len(body.split()) >= 8:
            sections.append(Section(text=body, label=current_label))
        buffer.clear()

    content_tags = ["h1", "h2", "h3", "h4", "p", "li", "td", "th",
                    "pre", "blockquote", "dd", "dt", "figcaption"]

    for el in main.find_all(content_tags):
        # Skip nested duplicates (e.g. a <p> inside an <li> already captured).
        if el.find_parent(["li", "td", "th", "blockquote"]) and el.name == "p":
            continue
        text = el.get_text(" ", strip=True)
        if not text:
            continue
        if el.name in ("h1", "h2", "h3", "h4"):
            flush()
            current_label = text[:120]
            buffer.append(text)
        else:
            buffer.append(text)

    flush()

    if not sections:
        fallback = _clean(main.get_text("\n", strip=True))
        if fallback:
            sections = [Section(text=fallback)]

    return ExtractedDoc(url=url, title=title or url, kind="html",
                        sections=sections)


def find_links(html: str, base_url: str) -> list[str]:
    """Return every absolute href on the page, in document order."""
    from urllib.parse import urljoin, urldefrag

    soup = BeautifulSoup(html, "lxml")
    out: list[str] = []
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith(("mailto:", "tel:", "javascript:", "#")):
            continue
        absolute, _ = urldefrag(urljoin(base_url, href))
        if absolute not in seen:
            seen.add(absolute)
            out.append(absolute)
    return out


# --------------------------------------------------------------------------
# PDF
# --------------------------------------------------------------------------

def extract_pdf(data: bytes, url: str) -> ExtractedDoc:
    """Extract per-page text (and simple tables) from a PDF."""
    try:
        import pdfplumber
    except ImportError:  # pragma: no cover - dependency guard
        return ExtractedDoc(url=url, title=url, kind="pdf",
                            error="pdfplumber is not installed")

    sections: list[Section] = []
    title = url.rsplit("/", 1)[-1] or url

    try:
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            meta_title = (pdf.metadata or {}).get("Title") or ""
            if isinstance(meta_title, str) and meta_title.strip():
                title = meta_title.strip()

            for index, page in enumerate(pdf.pages, start=1):
                parts: list[str] = []

                page_text = page.extract_text() or ""
                if page_text.strip():
                    parts.append(page_text)

                # Tables carry the numbers people ask about, so flatten
                # them into pipe-delimited rows rather than losing them.
                try:
                    for table in page.extract_tables() or []:
                        rows = [
                            " | ".join((cell or "").strip() for cell in row)
                            for row in table if any(row)
                        ]
                        if rows:
                            parts.append("[table]\n" + "\n".join(rows))
                except Exception:
                    pass

                body = _clean("\n\n".join(parts))
                if len(body.split()) >= 5:
                    sections.append(
                        Section(text=body, label=f"page {index}", page=index)
                    )
    except Exception as exc:
        return ExtractedDoc(url=url, title=title, kind="pdf",
                            error=f"could not read PDF: {exc}")

    doc = ExtractedDoc(url=url, title=title, kind="pdf", sections=sections)
    if not sections:
        doc.error = "no extractable text (likely a scanned PDF - OCR required)"
    return doc


# --------------------------------------------------------------------------
# DOCX
# --------------------------------------------------------------------------

def extract_docx(data: bytes, url: str) -> ExtractedDoc:
    """Extract paragraphs, headings and tables from a Word document."""
    try:
        import docx  # python-docx
    except ImportError:  # pragma: no cover - dependency guard
        return ExtractedDoc(url=url, title=url, kind="docx",
                            error="python-docx is not installed")

    title = url.rsplit("/", 1)[-1] or url
    sections: list[Section] = []

    try:
        document = docx.Document(io.BytesIO(data))

        core_title = (document.core_properties.title or "").strip()
        if core_title:
            title = core_title

        current_label = ""
        buffer: list[str] = []

        def flush() -> None:
            body = _clean("\n\n".join(buffer))
            if len(body.split()) >= 8:
                sections.append(Section(text=body, label=current_label))
            buffer.clear()

        for para in document.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            if para.style is not None and para.style.name.startswith("Heading"):
                flush()
                current_label = text[:120]
            buffer.append(text)
        flush()

        for table in document.tables:
            rows = [
                " | ".join(cell.text.strip() for cell in row.cells)
                for row in table.rows
            ]
            rows = [r for r in rows if r.replace("|", "").strip()]
            if rows:
                sections.append(
                    Section(text="[table]\n" + "\n".join(rows), label="table")
                )
    except Exception as exc:
        return ExtractedDoc(url=url, title=title, kind="docx",
                            error=f"could not read DOCX: {exc}")

    return ExtractedDoc(url=url, title=title, kind="docx", sections=sections)


# --------------------------------------------------------------------------
# Plain text / markdown / csv
# --------------------------------------------------------------------------

def extract_text(data: bytes, url: str) -> ExtractedDoc:
    text = _clean(data.decode("utf-8", errors="replace"))
    title = url.rsplit("/", 1)[-1] or url
    sections = [Section(text=text)] if text else []
    return ExtractedDoc(url=url, title=title, kind="text", sections=sections)


# --------------------------------------------------------------------------
# Dispatch
# --------------------------------------------------------------------------

EXTENSION_KINDS = {
    ".pdf": "pdf",
    ".docx": "docx",
    ".txt": "text",
    ".md": "text",
    ".markdown": "text",
    ".csv": "text",
    ".json": "text",
    ".rtf": "text",
}

# Formats we can see linked but cannot read; reported to the user instead
# of being silently dropped.
UNSUPPORTED_EXTENSIONS = {".doc", ".ppt", ".pptx", ".xls", ".xlsx", ".zip",
                          ".rar", ".7z", ".epub"}


def kind_for(url: str, content_type: str = "") -> str:
    """Classify a resource from its extension, falling back to MIME type."""
    path = url.split("?", 1)[0].split("#", 1)[0].lower()
    for ext, kind in EXTENSION_KINDS.items():
        if path.endswith(ext):
            return kind

    ct = (content_type or "").lower()
    if "pdf" in ct:
        return "pdf"
    if "wordprocessingml" in ct:
        return "docx"
    if "html" in ct or "xhtml" in ct:
        return "html"
    if ct.startswith("text/"):
        return "text"
    return "html" if not ct else "unknown"


def extract(data: bytes, url: str, kind: str) -> ExtractedDoc:
    if kind == "pdf":
        return extract_pdf(data, url)
    if kind == "docx":
        return extract_docx(data, url)
    if kind == "text":
        return extract_text(data, url)
    if kind == "html":
        return extract_html(data.decode("utf-8", errors="replace"), url)
    return ExtractedDoc(url=url, title=url, kind=kind,
                        error=f"unsupported format: {kind}")

"""SQLite-backed chunk and vector store.

A dedicated vector database is overkill for a desktop tool: a site with
2,000 chunks is a 2000x768 float32 matrix, about 6 MB, and a brute-force
cosine pass over it takes single-digit milliseconds in numpy. Keeping
everything in one SQLite file also means a workspace is one portable
file, and PyInstaller has nothing extra to bundle.
"""

from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

SCHEMA = """
CREATE TABLE IF NOT EXISTS workspaces (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    root_url    TEXT NOT NULL,
    embed_model TEXT NOT NULL DEFAULT '',
    created_at  REAL NOT NULL,
    updated_at  REAL NOT NULL,
    stats       TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS documents (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    url          TEXT NOT NULL,
    title        TEXT NOT NULL,
    kind         TEXT NOT NULL,
    word_count   INTEGER NOT NULL DEFAULT 0,
    fetched_at   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_documents_ws ON documents(workspace_id);

CREATE TABLE IF NOT EXISTS chunks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    document_id  INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    ordinal      INTEGER NOT NULL,
    text         TEXT NOT NULL,
    label        TEXT NOT NULL DEFAULT '',
    page         INTEGER,
    embedding    BLOB
);
CREATE INDEX IF NOT EXISTS idx_chunks_ws ON chunks(workspace_id);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id);

CREATE TABLE IF NOT EXISTS messages (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    role         TEXT NOT NULL,
    content      TEXT NOT NULL,
    sources      TEXT NOT NULL DEFAULT '[]',
    created_at   REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_ws ON messages(workspace_id);
"""


@dataclass
class Chunk:
    id: int
    text: str
    label: str
    page: int | None
    url: str
    title: str
    kind: str
    score: float = 0.0


class Store:
    def __init__(self, path: Path | str):
        self.path = str(path)
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(SCHEMA)
        self._conn.commit()
        # Cached (matrix, chunk-id list) per workspace, so repeated questions
        # do not re-read every embedding from disk.
        self._vectors: dict[int, tuple[np.ndarray, list[int]]] = {}

    def close(self) -> None:
        self._conn.close()

    # -- workspaces --------------------------------------------------------

    def create_workspace(self, name: str, root_url: str, embed_model: str) -> int:
        now = time.time()
        cur = self._conn.execute(
            "INSERT INTO workspaces (name, root_url, embed_model, created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (name, root_url, embed_model, now, now),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def list_workspaces(self) -> list[dict]:
        rows = self._conn.execute(
            """
            SELECT w.*,
                   (SELECT COUNT(*) FROM documents d WHERE d.workspace_id = w.id) AS doc_count,
                   (SELECT COUNT(*) FROM chunks c WHERE c.workspace_id = w.id)    AS chunk_count
            FROM workspaces w
            ORDER BY w.updated_at DESC
            """
        ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            try:
                item["stats"] = json.loads(item.get("stats") or "{}")
            except json.JSONDecodeError:
                item["stats"] = {}
            out.append(item)
        return out

    def get_workspace(self, workspace_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM workspaces WHERE id = ?", (workspace_id,)
        ).fetchone()
        if not row:
            return None
        item = dict(row)
        try:
            item["stats"] = json.loads(item.get("stats") or "{}")
        except json.JSONDecodeError:
            item["stats"] = {}
        return item

    def touch_workspace(self, workspace_id: int, stats: dict | None = None) -> None:
        if stats is None:
            self._conn.execute(
                "UPDATE workspaces SET updated_at = ? WHERE id = ?",
                (time.time(), workspace_id),
            )
        else:
            self._conn.execute(
                "UPDATE workspaces SET updated_at = ?, stats = ? WHERE id = ?",
                (time.time(), json.dumps(stats), workspace_id),
            )
        self._conn.commit()

    def delete_workspace(self, workspace_id: int) -> None:
        self._conn.execute("DELETE FROM workspaces WHERE id = ?", (workspace_id,))
        self._conn.commit()
        self._vectors.pop(workspace_id, None)

    # -- documents and chunks ---------------------------------------------

    def add_document(self, workspace_id: int, url: str, title: str,
                     kind: str, word_count: int) -> int:
        cur = self._conn.execute(
            "INSERT INTO documents (workspace_id, url, title, kind, word_count, fetched_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (workspace_id, url, title, kind, word_count, time.time()),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def add_chunks(self, workspace_id: int, document_id: int,
                   chunks: list[dict], embeddings: np.ndarray) -> None:
        """Persist chunks alongside their float32 embeddings."""
        vectors = np.asarray(embeddings, dtype=np.float32)
        rows = [
            (workspace_id, document_id, i, c["text"], c.get("label", ""),
             c.get("page"), vectors[i].tobytes())
            for i, c in enumerate(chunks)
        ]
        self._conn.executemany(
            "INSERT INTO chunks (workspace_id, document_id, ordinal, text, label, page, embedding)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            rows,
        )
        self._conn.commit()
        self._vectors.pop(workspace_id, None)

    def list_documents(self, workspace_id: int) -> list[dict]:
        rows = self._conn.execute(
            """
            SELECT d.*, (SELECT COUNT(*) FROM chunks c WHERE c.document_id = d.id) AS chunk_count
            FROM documents d WHERE d.workspace_id = ?
            ORDER BY d.kind, d.title
            """,
            (workspace_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def chunk_count(self, workspace_id: int) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) AS n FROM chunks WHERE workspace_id = ?", (workspace_id,)
        ).fetchone()
        return int(row["n"])

    # -- retrieval ---------------------------------------------------------

    def _matrix(self, workspace_id: int) -> tuple[np.ndarray, list[int]]:
        """Return the L2-normalised embedding matrix for a workspace."""
        cached = self._vectors.get(workspace_id)
        if cached is not None:
            return cached

        rows = self._conn.execute(
            "SELECT id, embedding FROM chunks"
            " WHERE workspace_id = ? AND embedding IS NOT NULL ORDER BY id",
            (workspace_id,),
        ).fetchall()

        if not rows:
            empty = (np.zeros((0, 0), dtype=np.float32), [])
            self._vectors[workspace_id] = empty
            return empty

        ids = [int(r["id"]) for r in rows]
        vectors = np.vstack(
            [np.frombuffer(r["embedding"], dtype=np.float32) for r in rows]
        )
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        vectors = vectors / norms

        self._vectors[workspace_id] = (vectors, ids)
        return vectors, ids

    def search(self, workspace_id: int, query_vector: np.ndarray,
               limit: int) -> list[tuple[int, float]]:
        """Return (chunk_id, cosine_similarity) for the closest chunks."""
        matrix, ids = self._matrix(workspace_id)
        if matrix.size == 0:
            return []

        query = np.asarray(query_vector, dtype=np.float32).ravel()
        norm = float(np.linalg.norm(query))
        if norm == 0:
            return []
        query = query / norm

        if matrix.shape[1] != query.shape[0]:
            # Embedding model changed after ingest; the vectors are unusable.
            return []

        scores = matrix @ query
        limit = min(limit, len(ids))
        top = np.argpartition(-scores, limit - 1)[:limit]
        top = top[np.argsort(-scores[top])]
        return [(ids[i], float(scores[i])) for i in top]

    def hydrate(self, chunk_ids: list[int]) -> dict[int, Chunk]:
        """Load full chunk rows (with document metadata) by id."""
        if not chunk_ids:
            return {}
        placeholders = ",".join("?" * len(chunk_ids))
        rows = self._conn.execute(
            f"""
            SELECT c.id, c.text, c.label, c.page, d.url, d.title, d.kind
            FROM chunks c JOIN documents d ON d.id = c.document_id
            WHERE c.id IN ({placeholders})
            """,
            chunk_ids,
        ).fetchall()
        return {
            int(r["id"]): Chunk(
                id=int(r["id"]), text=r["text"], label=r["label"] or "",
                page=r["page"], url=r["url"], title=r["title"], kind=r["kind"],
            )
            for r in rows
        }

    def keyword_search(self, workspace_id: int, terms: list[str],
                       limit: int) -> list[tuple[int, float]]:
        """Cheap lexical fallback so exact names and codes are not missed.

        Local embedding models are small, and they routinely miss literal
        matches like a course code or a form number. Scoring on term
        coverage rescues those.
        """
        if not terms:
            return []

        clauses = " OR ".join(["LOWER(c.text) LIKE ?"] * len(terms))
        params: list = [f"%{t.lower()}%" for t in terms]
        rows = self._conn.execute(
            f"""
            SELECT c.id, LOWER(c.text) AS body FROM chunks c
            WHERE c.workspace_id = ? AND ({clauses})
            LIMIT 400
            """,
            [workspace_id] + params,
        ).fetchall()

        scored: list[tuple[int, float]] = []
        for row in rows:
            body = row["body"]
            hits = sum(1 for t in terms if t.lower() in body)
            if hits:
                scored.append((int(row["id"]), hits / len(terms)))
        scored.sort(key=lambda x: -x[1])
        return scored[:limit]

    # -- chat history ------------------------------------------------------

    def add_message(self, workspace_id: int, role: str, content: str,
                    sources: list | None = None) -> None:
        self._conn.execute(
            "INSERT INTO messages (workspace_id, role, content, sources, created_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (workspace_id, role, content, json.dumps(sources or []), time.time()),
        )
        self._conn.commit()

    def history(self, workspace_id: int, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM messages WHERE workspace_id = ? ORDER BY id DESC LIMIT ?",
            (workspace_id, limit),
        ).fetchall()
        out = []
        for row in reversed(rows):
            item = dict(row)
            try:
                item["sources"] = json.loads(item["sources"])
            except json.JSONDecodeError:
                item["sources"] = []
            out.append(item)
        return out

    def clear_history(self, workspace_id: int) -> None:
        self._conn.execute("DELETE FROM messages WHERE workspace_id = ?", (workspace_id,))
        self._conn.commit()

"""Breadth-first, same-site crawler that also collects linked documents.

Design notes:
  * Documents (PDF/DOCX/...) are collected from anywhere on the site but
    are never themselves expanded for links, so a PDF-heavy site cannot
    blow past the page budget.
  * Documents are allowed one level beyond max_depth. A policy PDF is
    usually linked from the deepest page you were willing to visit, and
    dropping it there is the single most common way this kind of tool
    disappoints its user.
  * robots.txt is fetched once per host and honoured by default.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Awaitable
from urllib.parse import urlparse, urldefrag, urljoin
from urllib.robotparser import RobotFileParser

import httpx

from .config import Settings
from .extract import (
    ExtractedDoc, extract, find_links, kind_for,
    EXTENSION_KINDS, UNSUPPORTED_EXTENSIONS,
)

ProgressFn = Callable[[str, dict], None]

# Paths that are never worth spending a page budget on.
_SKIP_PATTERNS = (
    "/wp-admin", "/wp-login", "/login", "/signin", "/sign-in", "/register",
    "/signup", "/cart", "/checkout", "/logout", "/feed", "?replytocom",
    "/tag/", "/author/", "/comment", "/print/", "/share",
)

_SKIP_EXTENSIONS = (
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".ico", ".bmp", ".tiff",
    ".mp4", ".mp3", ".avi", ".mov", ".wav", ".webm", ".ogg", ".m4a",
    ".css", ".js", ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".exe", ".dmg", ".pkg", ".deb", ".rpm", ".apk", ".iso",
)


@dataclass
class CrawlResult:
    docs: list[ExtractedDoc] = field(default_factory=list)
    visited: int = 0
    skipped: list[tuple[str, str]] = field(default_factory=list)  # (url, why)
    stopped_reason: str = ""


def normalise(url: str) -> str:
    """Canonicalise a URL so trivial variants do not crawl twice."""
    url, _ = urldefrag(url.strip())
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    if (scheme == "http" and netloc.endswith(":80")) or \
       (scheme == "https" and netloc.endswith(":443")):
        netloc = netloc.rsplit(":", 1)[0]
    path = parsed.path or "/"
    if len(path) > 1 and path.endswith("/"):
        path = path.rstrip("/")
    rebuilt = f"{scheme}://{netloc}{path}"
    if parsed.query:
        rebuilt += f"?{parsed.query}"
    return rebuilt


def registrable(host: str) -> str:
    """Cheap eTLD+1 approximation, good enough for same-site checks."""
    host = host.lower().split(":")[0]
    parts = host.split(".")
    if len(parts) <= 2:
        return host
    # Handle common two-part public suffixes (co.uk, com.pk, edu.pk, ...).
    if parts[-2] in {"co", "com", "org", "net", "gov", "edu", "ac", "sch"} \
            and len(parts[-1]) <= 3:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def same_site(url: str, root: str, follow_subdomains: bool) -> bool:
    a, b = urlparse(url).netloc.lower(), urlparse(root).netloc.lower()
    if a == b:
        return True
    return follow_subdomains and registrable(a) == registrable(b)


def should_skip(url: str) -> str:
    """Return a reason to skip this URL, or an empty string to keep it."""
    lowered = url.lower()
    path = lowered.split("?", 1)[0]

    for ext in _SKIP_EXTENSIONS:
        if path.endswith(ext):
            return "media or asset file"
    for ext in UNSUPPORTED_EXTENSIONS:
        if path.endswith(ext):
            return f"unsupported format ({ext})"
    for pattern in _SKIP_PATTERNS:
        if pattern in lowered:
            return "non-content page"
    return ""


def is_document(url: str) -> bool:
    path = url.split("?", 1)[0].lower()
    return any(path.endswith(ext) for ext in EXTENSION_KINDS)


class RobotsCache:
    """Fetch and cache robots.txt rules per host."""

    def __init__(self, client: httpx.AsyncClient, user_agent: str):
        self._client = client
        self._agent = user_agent
        self._cache: dict[str, RobotFileParser | None] = {}

    async def allowed(self, url: str) -> bool:
        parsed = urlparse(url)
        host = f"{parsed.scheme}://{parsed.netloc}"

        if host not in self._cache:
            parser: RobotFileParser | None = None
            try:
                resp = await self._client.get(
                    urljoin(host, "/robots.txt"), timeout=10.0
                )
                if resp.status_code == 200 and len(resp.content) < 512_000:
                    parser = RobotFileParser()
                    parser.parse(resp.text.splitlines())
            except Exception:
                parser = None  # Unreachable robots.txt means "no rules".
            self._cache[host] = parser

        parser = self._cache[host]
        if parser is None:
            return True
        try:
            return parser.can_fetch(self._agent, url)
        except Exception:
            return True


async def crawl(
    start_url: str,
    settings: Settings,
    progress: ProgressFn | None = None,
    should_stop: Callable[[], bool] | None = None,
) -> CrawlResult:
    """Crawl start_url's site and return every document we could read."""

    def report(event: str, **payload) -> None:
        if progress:
            try:
                progress(event, payload)
            except Exception:
                pass

    def stopped() -> bool:
        return bool(should_stop and should_stop())

    if not start_url.startswith(("http://", "https://")):
        start_url = "https://" + start_url.lstrip("/")
    start_url = normalise(start_url)

    result = CrawlResult()
    seen: set[str] = {start_url}
    queue: deque[tuple[str, int]] = deque([(start_url, 0)])
    doc_queue: list[str] = []

    limits = httpx.Limits(max_connections=max(2, settings.concurrency))
    headers = {
        "User-Agent": settings.user_agent,
        "Accept": "text/html,application/xhtml+xml,application/pdf,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }

    async with httpx.AsyncClient(
        headers=headers,
        follow_redirects=True,
        timeout=httpx.Timeout(settings.request_timeout),
        limits=limits,
        verify=True,
    ) as client:
        robots = RobotsCache(client, settings.user_agent)
        semaphore = asyncio.Semaphore(max(1, settings.concurrency))
        max_bytes = settings.max_file_mb * 1024 * 1024

        async def fetch(url: str) -> tuple[bytes, str, str] | None:
            """Download a URL, returning (body, content_type, final_url)."""
            async with semaphore:
                if settings.crawl_delay:
                    await asyncio.sleep(settings.crawl_delay)
                try:
                    async with client.stream("GET", url) as resp:
                        if resp.status_code >= 400:
                            result.skipped.append((url, f"HTTP {resp.status_code}"))
                            return None

                        content_type = resp.headers.get("content-type", "")

                        declared = resp.headers.get("content-length")
                        if declared and declared.isdigit() and int(declared) > max_bytes:
                            result.skipped.append(
                                (url, f"larger than {settings.max_file_mb} MB")
                            )
                            return None

                        chunks: list[bytes] = []
                        total = 0
                        async for chunk in resp.aiter_bytes(65536):
                            total += len(chunk)
                            if total > max_bytes:
                                result.skipped.append(
                                    (url, f"larger than {settings.max_file_mb} MB")
                                )
                                return None
                            chunks.append(chunk)

                        return b"".join(chunks), content_type, str(resp.url)
                except httpx.TimeoutException:
                    result.skipped.append((url, "timed out"))
                except Exception as exc:
                    result.skipped.append((url, type(exc).__name__))
                return None

        async def handle_page(url: str, depth: int) -> list[str]:
            """Fetch one URL, store its text, and return links worth queuing."""
            if stopped():
                return []

            if settings.respect_robots and not await robots.allowed(url):
                result.skipped.append((url, "disallowed by robots.txt"))
                return []

            fetched = await fetch(url)
            if fetched is None:
                return []

            body, content_type, final_url = fetched
            result.visited += 1
            kind = kind_for(final_url, content_type)

            if kind == "unknown":
                result.skipped.append((url, f"unreadable type ({content_type})"))
                return []

            doc = extract(body, final_url, kind)

            if doc.error:
                result.skipped.append((url, doc.error))
            elif doc.word_count >= 25:
                result.docs.append(doc)
                report("document", url=final_url, title=doc.title,
                       kind=doc.kind, words=doc.word_count,
                       found=len(result.docs))
            else:
                result.skipped.append((url, "too little text"))

            report("progress", visited=result.visited,
                   queued=len(queue) + len(doc_queue),
                   docs=len(result.docs), url=final_url)

            if kind != "html":
                return []
            return find_links(body.decode("utf-8", errors="replace"), final_url)

        # ---- Breadth-first over HTML pages -------------------------------
        while queue and result.visited < settings.max_pages and not stopped():
            batch: list[tuple[str, int]] = []
            while queue and len(batch) < settings.concurrency \
                    and result.visited + len(batch) < settings.max_pages:
                batch.append(queue.popleft())

            if not batch:
                break

            link_lists = await asyncio.gather(
                *(handle_page(url, depth) for url, depth in batch)
            )

            for (source_url, depth), links in zip(batch, link_lists):
                for link in links:
                    try:
                        link = normalise(link)
                    except Exception:
                        continue
                    if link in seen:
                        continue
                    if not same_site(link, start_url, settings.follow_subdomains):
                        continue

                    reason = should_skip(link)
                    if reason:
                        seen.add(link)
                        if "unsupported format" in reason:
                            result.skipped.append((link, reason))
                        continue

                    if is_document(link):
                        # Documents get one level of grace beyond max_depth.
                        if depth <= settings.max_depth:
                            seen.add(link)
                            doc_queue.append(link)
                    elif depth + 1 <= settings.max_depth:
                        seen.add(link)
                        queue.append((link, depth + 1))

        if queue and result.visited >= settings.max_pages:
            result.stopped_reason = (
                f"reached the {settings.max_pages}-page limit with "
                f"{len(queue)} pages still queued"
            )

        # ---- Then the documents we found ---------------------------------
        if doc_queue and not stopped():
            report("phase", name="documents", count=len(doc_queue))
            budget = max(0, settings.max_pages * 2 - result.visited)
            pending = doc_queue[:budget]
            if len(doc_queue) > budget:
                result.skipped.append(
                    (f"{len(doc_queue) - budget} documents", "over the crawl budget")
                )

            for i in range(0, len(pending), settings.concurrency):
                if stopped():
                    break
                group = pending[i:i + settings.concurrency]
                await asyncio.gather(*(handle_page(u, 0) for u in group))

    if stopped():
        result.stopped_reason = "cancelled"

    report("done", visited=result.visited, docs=len(result.docs))
    return result

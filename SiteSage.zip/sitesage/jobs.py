"""Background ingest jobs: crawl, chunk, embed, store.

Ingest runs as an asyncio task with a live event log the UI polls. Crawl
and embedding both take minutes on a laptop, and a progress display that
names the file being read is the difference between "working" and
"frozen" in the user's mind.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from urllib.parse import urlparse

from .chunker import chunk_document, embedding_text
from .config import Settings
from .crawler import crawl
from .ollama_client import OllamaClient, OllamaError
from .store import Store


def friendly_name(url: str) -> str:
    """Turn a URL into a readable label for the sidebar.

    "https://www.northfield.edu/admissions" becomes "northfield.edu",
    which is what a user actually recognises in a list.
    """
    try:
        host = urlparse(url if "://" in url else f"https://{url}").netloc
    except Exception:
        host = ""
    host = (host or url).split(":")[0]
    if host.startswith("www."):
        host = host[4:]
    return host or url


@dataclass
class Job:
    id: str
    workspace_id: int | None
    root_url: str
    status: str = "starting"      # starting|crawling|embedding|done|error|cancelled
    message: str = "Starting..."
    pages_visited: int = 0
    docs_found: int = 0
    chunks_embedded: int = 0
    chunks_total: int = 0
    error: str = ""
    started_at: float = field(default_factory=time.time)
    finished_at: float | None = None
    log: list[dict] = field(default_factory=list)
    skipped: list[dict] = field(default_factory=list)
    cancel_requested: bool = False

    def note(self, text: str, level: str = "info") -> None:
        self.log.append({"t": time.time(), "text": text, "level": level})
        # Keep the log bounded; the UI only ever shows the tail.
        if len(self.log) > 300:
            del self.log[:100]

    def to_dict(self) -> dict[str, Any]:
        progress = 0.0
        if self.status == "crawling":
            progress = 0.05 + 0.45 * min(1.0, self.docs_found / 20)
        elif self.status == "embedding" and self.chunks_total:
            progress = 0.5 + 0.5 * (self.chunks_embedded / self.chunks_total)
        elif self.status == "done":
            progress = 1.0

        return {
            "id": self.id,
            "workspace_id": self.workspace_id,
            "root_url": self.root_url,
            "status": self.status,
            "message": self.message,
            "pages_visited": self.pages_visited,
            "docs_found": self.docs_found,
            "chunks_embedded": self.chunks_embedded,
            "chunks_total": self.chunks_total,
            "progress": round(progress, 3),
            "error": self.error,
            "elapsed": round((self.finished_at or time.time()) - self.started_at, 1),
            "log": self.log[-40:],
            "skipped": self.skipped[:60],
        }


class JobManager:
    def __init__(self, store: Store):
        self.store = store
        self.jobs: dict[str, Job] = {}
        self._tasks: dict[str, asyncio.Task] = {}

    def get(self, job_id: str) -> Job | None:
        return self.jobs.get(job_id)

    def cancel(self, job_id: str) -> bool:
        job = self.jobs.get(job_id)
        if not job or job.status in ("done", "error", "cancelled"):
            return False
        job.cancel_requested = True
        job.message = "Cancelling..."
        return True

    def start(self, root_url: str, name: str, settings: Settings) -> Job:
        job = Job(id=uuid.uuid4().hex[:12], workspace_id=None, root_url=root_url)
        self.jobs[job.id] = job
        task = asyncio.create_task(self._run(job, name, settings))
        self._tasks[job.id] = task
        task.add_done_callback(lambda _: self._tasks.pop(job.id, None))
        return job

    async def _run(self, job: Job, name: str, settings: Settings) -> None:
        client = OllamaClient(settings.ollama_host, settings.chat_model,
                              settings.embed_model)
        try:
            # -- preflight: fail fast with an actionable message ----------
            status = await client.status()
            if not status["running"]:
                raise OllamaError(status["error"])
            if not status.get("embed_model_ready"):
                raise OllamaError(
                    f"The embedding model `{settings.embed_model}` is not installed. "
                    f"Run: ollama pull {settings.embed_model}"
                )

            # -- crawl -----------------------------------------------------
            job.status = "crawling"
            job.message = "Crawling the site..."
            job.note(f"Crawling {job.root_url}")

            def on_progress(event: str, payload: dict) -> None:
                if event == "progress":
                    job.pages_visited = payload.get("visited", job.pages_visited)
                    job.message = f"Crawling... {job.pages_visited} pages read, {job.docs_found} kept"
                elif event == "document":
                    job.docs_found = payload.get("found", job.docs_found + 1)
                    kind = payload.get("kind", "")
                    marker = {"pdf": "PDF", "docx": "DOCX", "text": "TXT"}.get(kind, "page")
                    job.note(f"[{marker}] {payload.get('title', '')[:80]} "
                             f"({payload.get('words', 0):,} words)")
                elif event == "phase" and payload.get("name") == "documents":
                    job.message = f"Downloading {payload.get('count', 0)} documents..."
                    job.note(f"Found {payload.get('count', 0)} linked documents")

            result = await crawl(
                job.root_url, settings,
                progress=on_progress,
                should_stop=lambda: job.cancel_requested,
            )

            if job.cancel_requested:
                job.status, job.message = "cancelled", "Cancelled"
                job.finished_at = time.time()
                return

            job.skipped = [{"url": u, "why": w} for u, w in result.skipped]

            if not result.docs:
                raise RuntimeError(
                    "No readable content found. The site may be JavaScript-rendered, "
                    "blocked by robots.txt, or behind a login."
                )

            if result.stopped_reason:
                job.note(result.stopped_reason, "warn")

            # -- chunk -----------------------------------------------------
            job.status = "embedding"
            job.message = "Preparing text..."

            plans: list[tuple[Any, list[dict]]] = []
            total_chunks = 0
            for doc in result.docs:
                chunks = chunk_document(doc, settings.chunk_words,
                                        settings.chunk_overlap_words)
                if chunks:
                    plans.append((doc, chunks))
                    total_chunks += len(chunks)

            if not total_chunks:
                raise RuntimeError("Content was found but produced no usable text chunks.")

            job.chunks_total = total_chunks
            job.note(f"{len(plans)} documents -> {total_chunks:,} chunks")

            # -- workspace --------------------------------------------------
            workspace_id = self.store.create_workspace(
                name or friendly_name(job.root_url),
                job.root_url,
                settings.embed_model,
            )
            job.workspace_id = workspace_id

            # -- embed ------------------------------------------------------
            job.message = f"Embedding 0 / {total_chunks:,} chunks (local, no data leaves this machine)"

            for doc, chunks in plans:
                if job.cancel_requested:
                    job.status, job.message = "cancelled", "Cancelled"
                    job.finished_at = time.time()
                    return

                document_id = self.store.add_document(
                    workspace_id, doc.url, doc.title, doc.kind, doc.word_count
                )

                texts = [embedding_text(c, doc.title) for c in chunks]

                # Embed in slices so progress moves on big documents.
                vectors = []
                slice_size = 16
                for start in range(0, len(texts), slice_size):
                    if job.cancel_requested:
                        break
                    part = await client.embed(texts[start:start + slice_size],
                                              batch_size=slice_size)
                    vectors.append(part)
                    job.chunks_embedded += len(part)
                    job.message = (
                        f"Embedding {job.chunks_embedded:,} / {total_chunks:,} chunks "
                        "(local, no data leaves this machine)"
                    )

                if vectors:
                    import numpy as np
                    self.store.add_chunks(
                        workspace_id, document_id, chunks[:sum(len(v) for v in vectors)],
                        np.vstack(vectors),
                    )

            if job.cancel_requested:
                job.status, job.message = "cancelled", "Cancelled"
                job.finished_at = time.time()
                return

            # -- finish -----------------------------------------------------
            stats = {
                "pages_visited": result.visited,
                "documents": len(plans),
                "chunks": self.store.chunk_count(workspace_id),
                "pdfs": sum(1 for d, _ in plans if d.kind == "pdf"),
                "skipped": len(result.skipped),
                "indexed_at": time.time(),
            }
            self.store.touch_workspace(workspace_id, stats)

            job.status = "done"
            job.finished_at = time.time()
            job.message = (
                f"Ready. Indexed {stats['documents']} documents "
                f"({stats['pdfs']} PDFs) into {stats['chunks']:,} searchable chunks."
            )
            job.note(job.message, "success")

        except (OllamaError, RuntimeError) as exc:
            job.status, job.error = "error", str(exc)
            job.message = "Failed"
            job.finished_at = time.time()
            job.note(str(exc), "error")
        except asyncio.CancelledError:
            job.status, job.message = "cancelled", "Cancelled"
            job.finished_at = time.time()
            raise
        except Exception as exc:  # pragma: no cover - unexpected failures
            job.status = "error"
            job.error = f"{type(exc).__name__}: {exc}"
            job.message = "Failed"
            job.finished_at = time.time()
            job.note(job.error, "error")

"""Application configuration and on-disk paths.

Settings live in a JSON file inside the user's OS-appropriate app-data
directory so that a packaged binary never writes next to itself.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path


def app_data_dir() -> Path:
    """Return the per-user directory where SiteSage stores its data."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    path = base / "SiteSage"
    path.mkdir(parents=True, exist_ok=True)
    return path


DATA_DIR = app_data_dir()
DB_PATH = DATA_DIR / "sitesage.db"
SETTINGS_PATH = DATA_DIR / "settings.json"
CACHE_DIR = DATA_DIR / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class Settings:
    """User-tunable settings, persisted to settings.json."""

    # --- Ollama ---
    ollama_host: str = "http://127.0.0.1:11434"
    chat_model: str = "qwen2.5:7b-instruct"
    embed_model: str = "nomic-embed-text"

    # --- Crawl limits ---
    max_pages: int = 60
    max_depth: int = 3
    max_file_mb: int = 30
    request_timeout: int = 30
    crawl_delay: float = 0.3
    concurrency: int = 4
    respect_robots: bool = True
    follow_subdomains: bool = False
    user_agent: str = "SiteSageBot/1.0 (+local document assistant)"

    # --- Chunking ---
    chunk_words: int = 260
    chunk_overlap_words: int = 50

    # --- Retrieval ---
    top_k: int = 8
    candidate_pool: int = 40
    keyword_weight: float = 0.35
    min_score: float = 0.02

    # --- Generation ---
    temperature: float = 0.1
    num_ctx: int = 8192
    max_context_chars: int = 12000

    extra: dict = field(default_factory=dict)

    @classmethod
    def load(cls) -> "Settings":
        if SETTINGS_PATH.exists():
            try:
                raw = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return cls()
            known = {f for f in cls.__dataclass_fields__}
            return cls(**{k: v for k, v in raw.items() if k in known})
        return cls()

    def save(self) -> None:
        SETTINGS_PATH.write_text(
            json.dumps(asdict(self), indent=2), encoding="utf-8"
        )

    def update(self, values: dict) -> "Settings":
        known = {f for f in self.__dataclass_fields__}
        for key, value in values.items():
            if key in known and value is not None:
                current = getattr(self, key)
                # Preserve declared types so JSON strings from the UI coerce cleanly.
                if isinstance(current, bool):
                    value = bool(value)
                elif isinstance(current, int) and not isinstance(value, bool):
                    value = int(value)
                elif isinstance(current, float):
                    value = float(value)
                setattr(self, key, value)
        self.save()
        return self


SETTINGS = Settings.load()

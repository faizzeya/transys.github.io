"""FastAPI application: the local backend behind the desktop window.

Binds to 127.0.0.1 only. Nothing here is reachable from the network.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import __version__, __app_name__
from .config import SETTINGS, DB_PATH, DATA_DIR
from .jobs import JobManager
from .ollama_client import OllamaClient, OllamaError
from .rag import answer
from .store import Store

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title=__app_name__, version=__version__, docs_url=None, redoc_url=None)

store = Store(DB_PATH)
jobs = JobManager(store)


def client_for() -> OllamaClient:
    return OllamaClient(SETTINGS.ollama_host, SETTINGS.chat_model, SETTINGS.embed_model)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class IngestRequest(BaseModel):
    url: str
    name: str = ""


class AskRequest(BaseModel):
    workspace_id: int
    question: str


class SettingsRequest(BaseModel):
    values: dict


# ---------------------------------------------------------------------------
# System
# ---------------------------------------------------------------------------

@app.get("/api/health")
async def health():
    status = await client_for().status()
    return {
        "app": __app_name__,
        "version": __version__,
        "data_dir": str(DATA_DIR),
        "ollama": status,
        "settings": {
            "ollama_host": SETTINGS.ollama_host,
            "chat_model": SETTINGS.chat_model,
            "embed_model": SETTINGS.embed_model,
            "max_pages": SETTINGS.max_pages,
            "max_depth": SETTINGS.max_depth,
            "respect_robots": SETTINGS.respect_robots,
            "follow_subdomains": SETTINGS.follow_subdomains,
            "top_k": SETTINGS.top_k,
        },
    }


@app.get("/api/settings")
async def get_settings():
    from dataclasses import asdict
    return asdict(SETTINGS)


@app.post("/api/settings")
async def update_settings(req: SettingsRequest):
    from dataclasses import asdict
    SETTINGS.update(req.values)
    return asdict(SETTINGS)


# ---------------------------------------------------------------------------
# Ingest
# ---------------------------------------------------------------------------

@app.post("/api/ingest")
async def start_ingest(req: IngestRequest):
    url = req.url.strip()
    if not url:
        raise HTTPException(400, "A website address is required.")
    job = jobs.start(url, req.name.strip(), SETTINGS)
    return job.to_dict()


@app.get("/api/ingest/{job_id}")
async def ingest_status(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(404, "No such job.")
    return job.to_dict()


@app.post("/api/ingest/{job_id}/cancel")
async def cancel_ingest(job_id: str):
    return {"cancelled": jobs.cancel(job_id)}


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------

@app.get("/api/workspaces")
async def list_workspaces():
    return store.list_workspaces()


@app.get("/api/workspaces/{workspace_id}")
async def get_workspace(workspace_id: int):
    workspace = store.get_workspace(workspace_id)
    if not workspace:
        raise HTTPException(404, "No such workspace.")
    workspace["documents"] = store.list_documents(workspace_id)
    workspace["history"] = store.history(workspace_id)
    return workspace


@app.delete("/api/workspaces/{workspace_id}")
async def delete_workspace(workspace_id: int):
    store.delete_workspace(workspace_id)
    return {"deleted": True}


@app.post("/api/workspaces/{workspace_id}/clear-history")
async def clear_history(workspace_id: int):
    store.clear_history(workspace_id)
    return {"cleared": True}


# ---------------------------------------------------------------------------
# Ask
# ---------------------------------------------------------------------------

@app.post("/api/ask")
async def ask(req: AskRequest):
    """Stream a grounded answer back to the UI as newline-delimited JSON."""
    question = req.question.strip()
    if not question:
        raise HTTPException(400, "A question is required.")
    if not store.get_workspace(req.workspace_id):
        raise HTTPException(404, "No such workspace.")

    async def stream():
        client = client_for()
        try:
            async for event in answer(store, req.workspace_id, question,
                                      client, SETTINGS):
                yield json.dumps(event) + "\n"
        except OllamaError as exc:
            yield json.dumps({"type": "error", "error": str(exc)}) + "\n"
        except Exception as exc:  # pragma: no cover
            yield json.dumps({
                "type": "error",
                "error": f"{type(exc).__name__}: {exc}",
            }) + "\n"

    return StreamingResponse(
        stream(),
        media_type="application/x-ndjson",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Static UI
# ---------------------------------------------------------------------------

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
async def index():
    page = STATIC_DIR / "index.html"
    if not page.exists():
        return JSONResponse({"error": "UI files missing"}, status_code=500)
    return FileResponse(str(page))

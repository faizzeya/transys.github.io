"""Thin async client for a local Ollama server.

Only three endpoints matter here: /api/tags to check what is installed,
/api/embed for vectors, and /api/chat for answers. Written against
httpx directly so the app has no extra dependency and full control of
timeouts, which matter a lot when a 7B model is thinking on CPU.
"""

from __future__ import annotations

import json
from typing import AsyncIterator

import httpx
import numpy as np


class OllamaError(RuntimeError):
    """Raised with a message intended to be shown directly to the user."""


class OllamaClient:
    def __init__(self, host: str, chat_model: str, embed_model: str):
        self.host = host.rstrip("/")
        self.chat_model = chat_model
        self.embed_model = embed_model

    # -- health ------------------------------------------------------------

    async def status(self) -> dict:
        """Report whether Ollama is up and the required models are present."""
        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                resp = await client.get(f"{self.host}/api/tags")
                resp.raise_for_status()
                data = resp.json()
        except Exception as exc:
            return {
                "running": False,
                "models": [],
                "error": f"Cannot reach Ollama at {self.host} ({type(exc).__name__}). "
                         "Start it with `ollama serve`.",
            }

        names = [m.get("name", "") for m in data.get("models", [])]

        def installed(target: str) -> bool:
            # "qwen2.5:7b-instruct" should match a tag list entry exactly,
            # and a bare "qwen2.5" should match "qwen2.5:latest".
            return any(n == target or n.split(":")[0] == target.split(":")[0]
                       for n in names)

        return {
            "running": True,
            "models": names,
            "chat_model_ready": installed(self.chat_model),
            "embed_model_ready": installed(self.embed_model),
            "error": "",
        }

    # -- embeddings --------------------------------------------------------

    async def embed(self, texts: list[str], batch_size: int = 16,
                    timeout: float = 180.0) -> np.ndarray:
        """Embed a list of texts, returning an (n, dim) float32 array."""
        if not texts:
            return np.zeros((0, 0), dtype=np.float32)

        vectors: list[list[float]] = []
        async with httpx.AsyncClient(timeout=timeout) as client:
            for start in range(0, len(texts), batch_size):
                batch = texts[start:start + batch_size]
                try:
                    resp = await client.post(
                        f"{self.host}/api/embed",
                        json={"model": self.embed_model, "input": batch},
                    )
                    if resp.status_code == 404:
                        # Older Ollama builds only expose /api/embeddings,
                        # which takes a single prompt at a time.
                        for item in batch:
                            legacy = await client.post(
                                f"{self.host}/api/embeddings",
                                json={"model": self.embed_model, "prompt": item},
                            )
                            legacy.raise_for_status()
                            vectors.append(legacy.json()["embedding"])
                        continue
                    resp.raise_for_status()
                    payload = resp.json()
                    vectors.extend(payload.get("embeddings") or [payload["embedding"]])
                except httpx.HTTPStatusError as exc:
                    detail = exc.response.text[:200]
                    raise OllamaError(
                        f"Embedding failed ({exc.response.status_code}). "
                        f"Is `{self.embed_model}` pulled? Details: {detail}"
                    ) from exc
                except Exception as exc:
                    raise OllamaError(
                        f"Embedding failed: {type(exc).__name__}. "
                        f"Check that Ollama is running at {self.host}."
                    ) from exc

        return np.asarray(vectors, dtype=np.float32)

    async def embed_one(self, text: str) -> np.ndarray:
        result = await self.embed([text])
        return result[0] if len(result) else np.zeros((0,), dtype=np.float32)

    # -- chat --------------------------------------------------------------

    async def chat_stream(self, messages: list[dict], temperature: float = 0.1,
                          num_ctx: int = 8192,
                          timeout: float = 600.0) -> AsyncIterator[str]:
        """Yield answer tokens as the local model produces them."""
        payload = {
            "model": self.chat_model,
            "messages": messages,
            "stream": True,
            "options": {"temperature": temperature, "num_ctx": num_ctx},
        }

        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0)) as client:
                async with client.stream("POST", f"{self.host}/api/chat", json=payload) as resp:
                    if resp.status_code != 200:
                        body = (await resp.aread()).decode("utf-8", "replace")[:300]
                        raise OllamaError(
                            f"Ollama returned {resp.status_code}. "
                            f"Is `{self.chat_model}` pulled? Details: {body}"
                        )
                    async for line in resp.aiter_lines():
                        if not line.strip():
                            continue
                        try:
                            event = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        token = (event.get("message") or {}).get("content", "")
                        if token:
                            yield token
                        if event.get("done"):
                            break
        except OllamaError:
            raise
        except Exception as exc:
            raise OllamaError(
                f"Chat failed: {type(exc).__name__}. "
                f"Check that Ollama is running at {self.host}."
            ) from exc

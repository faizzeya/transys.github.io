"""Split extracted documents into overlapping, citable chunks.

Chunks respect paragraph boundaries where possible, because a chunk that
ends mid-sentence embeds poorly and reads badly when quoted back. Each
chunk keeps the label of the section it came from so the answer can cite
"page 12" or the heading it sat under.
"""

from __future__ import annotations

import re

from .extract import ExtractedDoc

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(])")


def _split_long_paragraph(paragraph: str, max_words: int) -> list[str]:
    """Break an oversized paragraph on sentence boundaries."""
    words = paragraph.split()
    if len(words) <= max_words:
        return [paragraph]

    pieces: list[str] = []
    current: list[str] = []
    count = 0

    for sentence in _SENTENCE_SPLIT.split(paragraph):
        n = len(sentence.split())
        if n > max_words:
            # A single sentence longer than the budget (tables, long lists):
            # fall back to a hard word-window split.
            if current:
                pieces.append(" ".join(current))
                current, count = [], 0
            sentence_words = sentence.split()
            for i in range(0, len(sentence_words), max_words):
                pieces.append(" ".join(sentence_words[i:i + max_words]))
            continue

        if count + n > max_words and current:
            pieces.append(" ".join(current))
            current, count = [], 0
        current.append(sentence)
        count += n

    if current:
        pieces.append(" ".join(current))
    return pieces


def chunk_document(doc: ExtractedDoc, chunk_words: int = 260,
                   overlap_words: int = 50) -> list[dict]:
    """Turn an ExtractedDoc into a list of chunk dicts ready for embedding."""
    chunks: list[dict] = []
    overlap_words = max(0, min(overlap_words, chunk_words // 2))

    for section in doc.sections:
        if not section.text.strip():
            continue

        paragraphs = [p.strip() for p in section.text.split("\n\n") if p.strip()]
        units: list[str] = []
        for paragraph in paragraphs:
            units.extend(_split_long_paragraph(paragraph, chunk_words))

        buffer: list[str] = []
        buffer_words = 0

        def flush() -> None:
            nonlocal buffer, buffer_words
            body = "\n\n".join(buffer).strip()
            if len(body.split()) >= 20:
                chunks.append({
                    "text": body,
                    "label": section.label,
                    "page": section.page,
                })
            if overlap_words and buffer:
                # Carry the tail of this chunk into the next one so an
                # answer spanning a chunk boundary is still retrievable.
                tail = " ".join(" ".join(buffer).split()[-overlap_words:])
                buffer = [tail] if tail else []
                buffer_words = len(tail.split())
            else:
                buffer, buffer_words = [], 0

        for unit in units:
            n = len(unit.split())
            if buffer_words + n > chunk_words and buffer:
                flush()
            buffer.append(unit)
            buffer_words += n

        body = "\n\n".join(buffer).strip()
        if len(body.split()) >= 20:
            chunks.append({
                "text": body,
                "label": section.label,
                "page": section.page,
            })

    return chunks


def embedding_text(chunk: dict, doc_title: str) -> str:
    """Prefix a chunk with its provenance before embedding.

    A chunk reading "Fees are due by 30 September" is ambiguous on its
    own; prefixing the document title and section makes it retrievable
    by a question that names the document.
    """
    header = doc_title
    if chunk.get("label"):
        header = f"{doc_title} - {chunk['label']}"
    return f"{header}\n\n{chunk['text']}"

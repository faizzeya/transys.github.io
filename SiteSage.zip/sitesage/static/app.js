/* SiteSage front-end.
   Plain ES modules-free JavaScript so the packaged app has no build step. */

(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const api = (path, opts) => fetch(path, opts).then(async (r) => {
    if (!r.ok) {
      const body = await r.json().catch(() => ({}));
      throw new Error(body.detail || `Request failed (${r.status})`);
    }
    return r.json();
  });

  const state = {
    workspaces: [],
    current: null,
    jobId: null,
    poller: null,
    streaming: false,
    settings: null,
  };

  // ---------------------------------------------------------------- utils

  const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
  ));

  const fmt = (n) => Number(n || 0).toLocaleString();

  function timeAgo(seconds) {
    if (!seconds) return "";
    const diff = Date.now() / 1000 - seconds;
    if (diff < 60) return "just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  }

  function showView(name) {
    document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
    $(`view-${name}`).classList.add("active");
  }

  /* Minimal markdown: bold, inline code, bullets, numbered lists,
     paragraphs, and [n] citation chips. Deliberately small — a full
     markdown parser is a dependency we do not need for answer text. */
  function renderMarkdown(text) {
    const lines = String(text).split("\n");
    let html = "";
    let listType = null;

    const closeList = () => { if (listType) { html += `</${listType}>`; listType = null; } };

    for (let raw of lines) {
      const line = raw.trim();
      if (!line) { closeList(); continue; }

      const bullet = line.match(/^[-*+]\s+(.*)$/);
      const numbered = line.match(/^\d+[.)]\s+(.*)$/);

      if (bullet) {
        if (listType !== "ul") { closeList(); html += "<ul>"; listType = "ul"; }
        html += `<li>${inline(bullet[1])}</li>`;
      } else if (numbered) {
        if (listType !== "ol") { closeList(); html += "<ol>"; listType = "ol"; }
        html += `<li>${inline(numbered[1])}</li>`;
      } else {
        closeList();
        html += `<p>${inline(line)}</p>`;
      }
    }
    closeList();
    return html;

    function inline(s) {
      let out = escapeHtml(s);
      out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
      out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
      // Citation chips: [1] or [1][3]
      out = out.replace(/\[(\d{1,2})\]/g,
        (_, n) => `<span class="cite" data-n="${n}">${n}</span>`);
      return out;
    }
  }

  // ------------------------------------------------------------- health

  async function refreshHealth() {
    const pill = $("ollama-status");
    const label = pill.querySelector(".status-text");
    try {
      const data = await api("/api/health");
      state.settings = data.settings;
      const o = data.ollama;

      if (!o.running) {
        pill.className = "status-pill status-bad";
        label.textContent = "Ollama not running";
        label.title = o.error;
      } else if (!o.chat_model_ready || !o.embed_model_ready) {
        pill.className = "status-pill status-warn";
        const missing = [];
        if (!o.chat_model_ready) missing.push(data.settings.chat_model);
        if (!o.embed_model_ready) missing.push(data.settings.embed_model);
        label.textContent = "Model not pulled";
        label.title = `Run: ollama pull ${missing.join(" && ollama pull ")}`;
      } else {
        pill.className = "status-pill status-ok";
        label.textContent = `Ollama ready · ${data.settings.chat_model}`;
        label.title = "";
      }
    } catch (err) {
      pill.className = "status-pill status-bad";
      label.textContent = "Backend unreachable";
    }
  }

  // --------------------------------------------------------- workspaces

  async function loadWorkspaces() {
    state.workspaces = await api("/api/workspaces");
    const list = $("workspace-list");

    if (!state.workspaces.length) {
      list.innerHTML = '<div class="empty-hint">Nothing indexed yet.</div>';
      return;
    }

    list.innerHTML = state.workspaces.map((w) => `
      <div class="ws-item${state.current && state.current.id === w.id ? " active" : ""}"
           data-id="${w.id}">
        <div class="ws-name">${escapeHtml(w.name)}</div>
        <div class="ws-sub">${fmt(w.doc_count)} docs · ${timeAgo(w.updated_at)}</div>
        <button class="ws-del" data-del="${w.id}" title="Delete">&times;</button>
      </div>
    `).join("");

    list.querySelectorAll(".ws-item").forEach((el) => {
      el.addEventListener("click", (e) => {
        if (e.target.dataset.del) return;
        openWorkspace(Number(el.dataset.id));
      });
    });

    list.querySelectorAll("[data-del]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const id = Number(btn.dataset.del);
        const ws = state.workspaces.find((w) => w.id === id);
        if (!confirm(`Delete "${ws ? ws.name : "this site"}" and everything indexed from it?`)) return;
        await fetch(`/api/workspaces/${id}`, { method: "DELETE" });
        if (state.current && state.current.id === id) {
          state.current = null;
          showView("start");
        }
        loadWorkspaces();
      });
    });
  }

  async function openWorkspace(id) {
    const ws = await api(`/api/workspaces/${id}`);
    state.current = ws;

    $("chat-name").textContent = ws.name;
    const s = ws.stats || {};
    $("chat-meta").textContent =
      `${fmt(s.documents || ws.doc_count)} documents · ${fmt(s.pdfs || 0)} PDFs · ` +
      `${fmt(s.chunks || ws.chunk_count)} chunks · ${escapeHtml(ws.root_url)}`;

    $("messages").innerHTML = "";
    (ws.history || []).forEach((m) => {
      if (m.role === "user") addUserMessage(m.content);
      else addAssistantMessage(m.content, m.sources || []);
    });

    renderSuggestions();
    showView("chat");
    loadWorkspaces();
    scrollMessages();
    $("question-input").focus();
  }

  function renderSuggestions() {
    const box = $("suggestions");
    if ($("messages").children.length > 0) { box.innerHTML = ""; return; }

    const ideas = [
      "What is this site about?",
      "Summarise the key documents",
      "What are the important dates or deadlines?",
      "List any fees, prices or costs mentioned",
      "What are the eligibility or entry requirements?",
    ];
    box.innerHTML = ideas
      .map((q) => `<button class="suggestion">${escapeHtml(q)}</button>`)
      .join("");
    box.querySelectorAll(".suggestion").forEach((b) => {
      b.addEventListener("click", () => {
        $("question-input").value = b.textContent;
        $("ask-form").dispatchEvent(new Event("submit", { cancelable: true }));
      });
    });
  }

  // ------------------------------------------------------------- ingest

  $("ingest-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const url = $("url-input").value.trim();
    const errBox = $("start-error");
    errBox.classList.add("hidden");

    if (!url) return;

    try {
      await api("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          values: {
            max_pages: Number($("opt-pages").value) || 60,
            max_depth: Number($("opt-depth").value) || 3,
            respect_robots: $("opt-robots").checked,
            follow_subdomains: $("opt-subdomains").checked,
          },
        }),
      });

      const job = await api("/api/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, name: "" }),
      });

      state.jobId = job.id;
      $("ingest-title").textContent = `Indexing ${url}`;
      $("ingest-error").classList.add("hidden");
      $("open-chat-btn").classList.add("hidden");
      $("back-btn").classList.add("hidden");
      $("cancel-btn").classList.remove("hidden");
      $("ingest-log").innerHTML = "";
      showView("ingest");
      pollJob();
    } catch (err) {
      errBox.textContent = err.message;
      errBox.classList.remove("hidden");
    }
  });

  function pollJob() {
    clearInterval(state.poller);
    state.poller = setInterval(async () => {
      if (!state.jobId) return;
      let job;
      try {
        job = await api(`/api/ingest/${state.jobId}`);
      } catch {
        return;
      }

      $("progress-bar").style.width = `${Math.round(job.progress * 100)}%`;
      $("ingest-message").textContent = job.message;
      $("stat-pages").textContent = fmt(job.pages_visited);
      $("stat-docs").textContent = fmt(job.docs_found);
      $("stat-chunks").textContent = fmt(job.chunks_embedded);
      $("stat-elapsed").textContent = `${Math.round(job.elapsed)}s`;

      const log = $("ingest-log");
      log.innerHTML = job.log
        .map((l) => `<div class="log-line ${l.level}">${escapeHtml(l.text)}</div>`)
        .join("");
      log.scrollTop = log.scrollHeight;

      if (["done", "error", "cancelled"].includes(job.status)) {
        clearInterval(state.poller);
        state.poller = null;
        $("cancel-btn").classList.add("hidden");
        $("back-btn").classList.remove("hidden");

        if (job.status === "done") {
          $("ingest-title").textContent = "Indexing complete";
          $("open-chat-btn").classList.remove("hidden");
          $("open-chat-btn").onclick = () => openWorkspace(job.workspace_id);
          loadWorkspaces();
        } else if (job.status === "error") {
          $("ingest-title").textContent = "Indexing failed";
          const box = $("ingest-error");
          box.textContent = job.error;
          box.classList.remove("hidden");
        } else {
          $("ingest-title").textContent = "Cancelled";
        }
      }
    }, 700);
  }

  $("cancel-btn").addEventListener("click", async () => {
    if (state.jobId) await fetch(`/api/ingest/${state.jobId}/cancel`, { method: "POST" });
  });

  $("back-btn").addEventListener("click", () => showView("start"));
  $("new-btn").addEventListener("click", () => {
    state.current = null;
    $("url-input").value = "";
    $("start-error").classList.add("hidden");
    showView("start");
    loadWorkspaces();
    $("url-input").focus();
  });

  // ---------------------------------------------------------------- ask

  function addUserMessage(text) {
    const el = document.createElement("div");
    el.className = "msg msg-user";
    el.innerHTML = `<div class="bubble">${escapeHtml(text)}</div>`;
    $("messages").appendChild(el);
    return el;
  }

  function addAssistantMessage(text, sources) {
    const el = document.createElement("div");
    el.className = "msg msg-assistant";
    el.innerHTML = `<div class="bubble">${renderMarkdown(text)}</div>`;
    if (sources && sources.length) el.appendChild(buildSources(sources));
    wireCitations(el);
    $("messages").appendChild(el);
    return el;
  }

  function buildSources(sources) {
    const wrap = document.createElement("div");
    wrap.className = "sources";
    wrap.innerHTML =
      `<div class="sources-label">Sources</div>` +
      sources.map((s) => {
        const tag = s.kind === "pdf" ? '<span class="kind-tag kind-pdf">PDF</span>'
          : s.kind === "docx" ? '<span class="kind-tag kind-docx">DOCX</span>'
          : '<span class="kind-tag">PAGE</span>';
        const loc = s.label ? ` · ${escapeHtml(s.label)}` : "";
        return `
          <div class="source" data-n="${s.n}">
            <div class="source-n">${s.n}</div>
            <div class="source-body">
              <div class="source-title">${tag}${escapeHtml(s.title)}</div>
              <div class="source-loc">
                <a href="${escapeHtml(s.url)}" target="_blank" rel="noopener">${escapeHtml(s.url)}</a>${loc}
              </div>
            </div>
          </div>`;
      }).join("");
    return wrap;
  }

  function wireCitations(root) {
    root.querySelectorAll(".cite").forEach((chip) => {
      chip.addEventListener("click", () => {
        const target = root.querySelector(`.source[data-n="${chip.dataset.n}"]`);
        if (!target) return;
        target.scrollIntoView({ behavior: "smooth", block: "center" });
        target.classList.add("flash");
        setTimeout(() => target.classList.remove("flash"), 1200);
      });
    });
  }

  function scrollMessages() {
    const box = $("messages");
    box.scrollTop = box.scrollHeight;
  }

  $("ask-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (state.streaming || !state.current) return;

    const input = $("question-input");
    const question = input.value.trim();
    if (!question) return;

    input.value = "";
    input.style.height = "auto";
    $("suggestions").innerHTML = "";
    addUserMessage(question);
    scrollMessages();

    state.streaming = true;
    $("ask-btn").disabled = true;

    const el = document.createElement("div");
    el.className = "msg msg-assistant";
    el.innerHTML = `<div class="bubble"><div class="thinking"><i></i><i></i><i></i></div></div>`;
    $("messages").appendChild(el);
    scrollMessages();

    const bubble = el.querySelector(".bubble");
    let sources = [];
    let answerText = "";

    try {
      const resp = await fetch("/api/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workspace_id: state.current.id, question }),
      });

      if (!resp.ok || !resp.body) throw new Error(`Request failed (${resp.status})`);

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let first = true;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
          if (!line.trim()) continue;
          let ev;
          try { ev = JSON.parse(line); } catch { continue; }

          if (ev.type === "sources") {
            sources = ev.sources || [];
          } else if (ev.type === "token") {
            if (first) { bubble.innerHTML = ""; first = false; }
            answerText += ev.text;
            bubble.innerHTML = renderMarkdown(answerText);
            scrollMessages();
          } else if (ev.type === "error") {
            bubble.innerHTML = `<div class="error-box">${escapeHtml(ev.error)}</div>`;
            sources = [];
          }
        }
      }

      if (answerText && sources.length) {
        el.appendChild(buildSources(sources));
        wireCitations(el);
      }
    } catch (err) {
      bubble.innerHTML = `<div class="error-box">${escapeHtml(err.message)}</div>`;
    } finally {
      state.streaming = false;
      $("ask-btn").disabled = false;
      scrollMessages();
      input.focus();
    }
  });

  const qi = $("question-input");
  qi.addEventListener("input", () => {
    qi.style.height = "auto";
    qi.style.height = `${Math.min(qi.scrollHeight, 160)}px`;
  });
  qi.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      $("ask-form").dispatchEvent(new Event("submit", { cancelable: true }));
    }
  });

  $("clear-btn").addEventListener("click", async () => {
    if (!state.current) return;
    if (!confirm("Clear the conversation for this site? The index is kept.")) return;
    await fetch(`/api/workspaces/${state.current.id}/clear-history`, { method: "POST" });
    $("messages").innerHTML = "";
    renderSuggestions();
  });

  // ------------------------------------------------------------- drawer

  $("docs-btn").addEventListener("click", async () => {
    if (!state.current) return;
    const ws = await api(`/api/workspaces/${state.current.id}`);
    const docs = ws.documents || [];

    const groups = { pdf: [], docx: [], html: [], text: [] };
    docs.forEach((d) => (groups[d.kind] || groups.html).push(d));

    const labels = { pdf: "PDF documents", docx: "Word documents",
                     html: "Web pages", text: "Text files" };

    $("drawer-body").innerHTML = Object.entries(groups)
      .filter(([, items]) => items.length)
      .map(([kind, items]) => `
        <div class="doc-group-label">${labels[kind]} (${items.length})</div>
        ${items.map((d) => `
          <div class="doc-row">
            <div class="doc-title"><a href="${escapeHtml(d.url)}" target="_blank" rel="noopener">${escapeHtml(d.title)}</a></div>
            <div class="doc-sub">${fmt(d.word_count)} words · ${fmt(d.chunk_count)} chunks</div>
          </div>`).join("")}
      `).join("") || '<div class="empty-hint">No documents.</div>';

    $("drawer").classList.remove("hidden");
  });

  $("drawer-close").addEventListener("click", () => $("drawer").classList.add("hidden"));

  // ------------------------------------------------------------ settings

  $("settings-btn").addEventListener("click", async () => {
    const [settings, health] = await Promise.all([
      api("/api/settings"),
      api("/api/health"),
    ]);
    $("set-host").value = settings.ollama_host;
    $("set-chat").value = settings.chat_model;
    $("set-embed").value = settings.embed_model;
    $("set-topk").value = settings.top_k;
    $("set-ctx").value = settings.num_ctx;

    const models = health.ollama.models || [];
    $("model-list").innerHTML = models.length
      ? `Installed models:<br>${models.map(escapeHtml).join("<br>")}`
      : "No models detected. Pull one with:<br>ollama pull qwen2.5:7b-instruct<br>ollama pull nomic-embed-text";

    $("settings-modal").classList.remove("hidden");
  });

  $("settings-close").addEventListener("click", () => $("settings-modal").classList.add("hidden"));

  $("settings-save").addEventListener("click", async () => {
    await api("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        values: {
          ollama_host: $("set-host").value.trim(),
          chat_model: $("set-chat").value.trim(),
          embed_model: $("set-embed").value.trim(),
          top_k: Number($("set-topk").value),
          num_ctx: Number($("set-ctx").value),
        },
      }),
    });
    $("settings-modal").classList.add("hidden");
    refreshHealth();
  });

  // ---------------------------------------------------------------- boot

  refreshHealth();
  loadWorkspaces();
  setInterval(refreshHealth, 20000);
  $("url-input").focus();
})();

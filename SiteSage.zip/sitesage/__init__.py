"""SiteSage - ask questions about any website and its documents, entirely offline."""

__version__ = "1.0.0"
__app_name__ = "SiteSage"

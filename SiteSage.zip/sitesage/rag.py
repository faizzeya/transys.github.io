"""Retrieval and grounded answer generation.

Two decisions here carry most of the answer quality:

  1. Hybrid retrieval. Small local embedding models miss literal strings
     (a course code, a form number, a person's surname). A lexical pass
     is blended in so those still surface.

  2. A strict prompt. A 7B model left unconstrained will happily answer
     from its own pretraining. The prompt forces it to answer only from
     the supplied context and to say so when the context is silent.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import AsyncIterator

import numpy as np

from .config import Settings
from .ollama_client import OllamaClient
from .store import Store, Chunk

_STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "if", "then", "than", "that", "this",
    "these", "those", "is", "are", "was", "were", "be", "been", "being", "am",
    "do", "does", "did", "have", "has", "had", "of", "in", "on", "at", "to",
    "for", "with", "by", "from", "about", "as", "into", "over", "after",
    "what", "when", "where", "who", "whom", "which", "why", "how", "can",
    "could", "would", "should", "will", "shall", "may", "might", "must",
    "it", "its", "they", "them", "their", "there", "here", "you", "your",
    "i", "me", "my", "we", "us", "our", "he", "she", "his", "her", "not",
    "no", "yes", "all", "any", "some", "more", "most", "other", "such",
    "tell", "give", "show", "list", "explain", "describe", "please", "does",
}

SYSTEM_PROMPT = """You are SiteSage, a research assistant that answers questions strictly from the excerpts provided to you.

Rules you must follow:
1. Answer ONLY from the CONTEXT below. Never use outside knowledge, and never guess.
2. If the context does not contain the answer, say plainly: "I couldn't find that in the indexed pages and documents." Then, if relevant, name what the context does cover that is closest.
3. Cite your sources inline using the bracketed numbers shown on each excerpt, like [1] or [2][4]. Every factual claim needs a citation.
4. Quote exact figures, dates, names, and amounts as they appear. Do not round or rephrase numbers.
5. If different sources disagree, say so and cite both.
6. Be direct and concise. No preamble, no restating the question, no offers of further help.
"""


@dataclass
class RetrievedContext:
    chunks: list[Chunk]
    context_text: str
    sources: list[dict]


def keywords(question: str) -> list[str]:
    """Pull the distinctive terms out of a question for the lexical pass."""
    # Preserve codes and identifiers such as "SEN-323" or "FORM-16A".
    codes = re.findall(r"\b[A-Za-z]{2,}[-_ ]?\d{2,}[A-Za-z]?\b", question)
    words = re.findall(r"[A-Za-z][A-Za-z0-9'&.-]{2,}", question)

    terms: list[str] = []
    seen: set[str] = set()
    for term in codes + words:
        cleaned = term.strip(".-'").lower()
        if len(cleaned) < 3 or cleaned in _STOPWORDS or cleaned in seen:
            continue
        seen.add(cleaned)
        terms.append(term.strip(".-'"))
    return terms[:8]


async def retrieve(store: Store, workspace_id: int, question: str,
                   client: OllamaClient, settings: Settings) -> RetrievedContext:
    """Find the passages most likely to answer the question."""
    query_vector = await client.embed_one(question)

    semantic = store.search(workspace_id, query_vector, settings.candidate_pool)
    lexical = store.keyword_search(workspace_id, keywords(question),
                                   settings.candidate_pool)

    # Blend the two rankings. Semantic scores are cosine similarities in
    # roughly [0, 1]; lexical scores are term-coverage fractions. Both
    # are min-max normalised first so neither drowns the other out.
    combined: dict[int, float] = {}

    def blend(pairs: list[tuple[int, float]], weight: float) -> None:
        if not pairs:
            return
        values = [s for _, s in pairs]
        low, high = min(values), max(values)
        spread = (high - low) or 1.0
        for chunk_id, score in pairs:
            normalised = (score - low) / spread
            combined[chunk_id] = combined.get(chunk_id, 0.0) + weight * normalised

    blend(semantic, 1.0 - settings.keyword_weight)
    blend(lexical, settings.keyword_weight)

    if not combined:
        return RetrievedContext(chunks=[], context_text="", sources=[])

    ranked = sorted(combined.items(), key=lambda kv: -kv[1])
    ranked = [(cid, s) for cid, s in ranked if s >= settings.min_score]
    ranked = ranked[:settings.top_k]

    rows = store.hydrate([cid for cid, _ in ranked])

    chunks: list[Chunk] = []
    for chunk_id, score in ranked:
        chunk = rows.get(chunk_id)
        if chunk:
            chunk.score = score
            chunks.append(chunk)

    # Build the context block, respecting the character budget so a long
    # retrieval cannot overflow the model's context window.
    blocks: list[str] = []
    sources: list[dict] = []
    used = 0

    for index, chunk in enumerate(chunks, start=1):
        location = chunk.label or ""
        header = f"[{index}] {chunk.title}"
        if location:
            header += f" ({location})"
        header += f"\nURL: {chunk.url}"

        block = f"{header}\n{chunk.text}"
        if used + len(block) > settings.max_context_chars and blocks:
            break

        blocks.append(block)
        used += len(block)
        sources.append({
            "n": index,
            "title": chunk.title,
            "url": chunk.url,
            "label": location,
            "page": chunk.page,
            "kind": chunk.kind,
            "score": round(chunk.score, 4),
            "snippet": chunk.text[:320] + ("..." if len(chunk.text) > 320 else ""),
        })

    return RetrievedContext(
        chunks=chunks[:len(blocks)],
        context_text="\n\n---\n\n".join(blocks),
        sources=sources,
    )


def build_messages(question: str, context: RetrievedContext,
                   history: list[dict]) -> list[dict]:
    """Assemble the message list sent to the local model."""
    messages: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]

    # A short slice of history keeps follow-ups ("and what about the fee?")
    # coherent without spending the whole context window on chat log.
    for turn in history[-4:]:
        if turn["role"] in ("user", "assistant") and turn["content"].strip():
            messages.append({
                "role": turn["role"],
                "content": turn["content"][:1500],
            })

    if context.context_text:
        user_content = (
            f"CONTEXT:\n\n{context.context_text}\n\n"
            f"---\n\nQUESTION: {question}\n\n"
            "Answer using only the context above, with inline [n] citations."
        )
    else:
        user_content = (
            f"QUESTION: {question}\n\n"
            "No relevant excerpts were found in the indexed content. "
            "Tell the user you couldn't find this in the indexed pages and documents."
        )

    messages.append({"role": "user", "content": user_content})
    return messages


async def answer(store: Store, workspace_id: int, question: str,
                 client: OllamaClient, settings: Settings) -> AsyncIterator[dict]:
    """Stream a grounded answer, emitting sources first then tokens."""
    context = await retrieve(store, workspace_id, question, client, settings)
    yield {"type": "sources", "sources": context.sources}

    history = store.history(workspace_id, limit=8)
    messages = build_messages(question, context, history)

    collected: list[str] = []
    async for token in client.chat_stream(
        messages,
        temperature=settings.temperature,
        num_ctx=settings.num_ctx,
    ):
        collected.append(token)
        yield {"type": "token", "text": token}

    full = "".join(collected).strip()
    store.add_message(workspace_id, "user", question)
    store.add_message(workspace_id, "assistant", full, context.sources)

    yield {"type": "done", "answer": full, "sources": context.sources}
